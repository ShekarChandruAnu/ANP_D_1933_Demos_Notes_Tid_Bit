package com.cts.client;

public class ClientUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			EmployeeDataManagement edm = new EmployeeDataManagement();
			edm.showMenu();
	}

}
