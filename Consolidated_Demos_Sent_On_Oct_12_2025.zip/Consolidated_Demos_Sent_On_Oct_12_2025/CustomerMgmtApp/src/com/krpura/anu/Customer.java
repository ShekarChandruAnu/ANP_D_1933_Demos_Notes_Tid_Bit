package com.krpura.anu;

//POJO CLASS BEAN
public class Customer {
	
	String customerId;
	String customerName;
	String customerAddress;
	String customerPhone;
	int purchaseValue;
	float salesTax;
	
	public Customer() {
		super();
	}

	public Customer(String customerId, String customerName, String customerAddress, String customerPhone,
			int purchaseValue, float salesTax) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.customerPhone = customerPhone;
		this.purchaseValue = purchaseValue;
		this.salesTax = salesTax;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	public int getPurchaseValue() {
		return purchaseValue;
	}

	public void setPurchaseValue(int purchaseValue) {
		this.purchaseValue = purchaseValue;
	}

	public float getSalesTax() {
		return salesTax;
	}

	public void setSalesTax(float salesTax) {
		this.salesTax = salesTax;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerAddress="
				+ customerAddress + ", customerPhone=" + customerPhone + ", purchaseValue=" + purchaseValue
				+ ", salesTax=" + salesTax + "]";
	}
	
	
	
	

	
	

}
