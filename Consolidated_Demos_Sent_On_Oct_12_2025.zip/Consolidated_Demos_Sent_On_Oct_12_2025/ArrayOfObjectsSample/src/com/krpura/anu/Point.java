package com.krpura.anu;

public class Point {
	
	int xCoord,yCoord;
	public Point() {
		super();  // super vs this
	}
	public Point(int xCoord, int yCoord) {
		super();
		this.xCoord = xCoord;
		this.yCoord = yCoord;
	}
	public void displayPoints()
	{
		System.out.println("The X Coordinate is "+xCoord+" And Y Coordinate is "+yCoord);
	}
	
}
