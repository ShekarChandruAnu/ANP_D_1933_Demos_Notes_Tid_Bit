package com.krpura.anu;

public class PointManipulator {

	public int calculateSum(int a,int b)
	{
		int sum = a + b;
		return sum;
	}
	public Point getPoint()
	{
		Point p1 = new Point(10,20);
		//----
		//--
		return p1;
	}
	//returns an array of Objects of Point type
	public Point[] manipulatePoints()
	{
		Point[] points = new Point[10];// DECLARATION
		/*points[0]= new Point(10,11);
		points[1]= new Point(20,21);
		points[0]= new Point(10,11);*/
		for(int i=0;i<10;i++)
		{
			points[i] = new Point(i+10,i+20);
		}
				return points;
				
				//points[0].displayPoints() points[1].displayPoints()
	}
	/*
	public Student[] getStudents()
	{
		
	}*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PointManipulator pointManipulator = new PointManipulator();
		/*int result = pointManipulator.calculateSum(100, 200);
		Point myPoint = pointManipulator.getPoint();*/
		Point myPoints[] = pointManipulator.manipulatePoints();
		for(int i=0;i<10;i++)
		{
			myPoints[i].displayPoints();
		}
		System.out.println("-------");
		for(Point point:myPoints)
		{
			point.displayPoints();
		}
		
	}

}
