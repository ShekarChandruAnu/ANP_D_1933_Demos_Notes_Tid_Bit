package com.krpura.anu;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class DeSerializationSample {

	ObjectInputStream ois;
	public void deSerializeObjects()
	{
		try {
			ois = new ObjectInputStream(new FileInputStream("buyers.txt"));
			ArrayList <Customer> customersRead = (ArrayList<Customer>) ois.readObject();
			System.out.println("The Customer Objects DESerialized are....");
			//System.out.println(customersRead);
			for(Customer c : customersRead)
			{
				System.out.println(c);
			}
			ois.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(ClassNotFoundException cnfe)
		{
			cnfe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DeSerializationSample dsls = new DeSerializationSample();
		dsls.deSerializeObjects();
	}

}
