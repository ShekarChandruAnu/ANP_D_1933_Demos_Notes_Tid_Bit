package com.krpura.anu;

import java.io.BufferedOutputStream;
import java.io.IOException;

public class BufferedOutputStreamMonitor {

		BufferedOutputStream bos;
		String str = "We are writing data to monitor thru buffered Stream";
		byte[] mybytes = new byte[100];
		public void writeToMonitorThruBufferStream()
		{
		//	bos = new BufferedOutputStream(new FileOutputStream("dealer.txt"))
		// bos.write("hello") takes the data to Dealer.txt
			bos = new BufferedOutputStream(System.out);
			mybytes = str.getBytes();
			try {
				bos.write(mybytes);
				bos.flush();
				
				System.out.println("We have written data successfully to Monitor....");
				bos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}//goes to monitor
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BufferedOutputStreamMonitor bos = new BufferedOutputStreamMonitor();
		bos.writeToMonitorThruBufferStream();

	}

}
