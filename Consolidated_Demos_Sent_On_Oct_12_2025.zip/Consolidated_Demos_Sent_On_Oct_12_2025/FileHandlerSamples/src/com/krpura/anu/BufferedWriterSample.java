package com.krpura.anu;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class BufferedWriterSample {

	BufferedWriter bw ;
	String str = "Content being written into Char Stream using Buffer";
	public void writeToCharStreamUsingBuffer()
	{
		try {
			//bw = new BufferedWriter(new FileWriter("student.txt"),10000);
			bw = new BufferedWriter(new FileWriter("student.txt"));
			bw.write(str);
			bw.flush();
			bw.close();
			System.out.println("We have successfully written into Char Stream using Buffer....");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedWriterSample bws = new BufferedWriterSample();
		bws.writeToCharStreamUsingBuffer();

	}

}
