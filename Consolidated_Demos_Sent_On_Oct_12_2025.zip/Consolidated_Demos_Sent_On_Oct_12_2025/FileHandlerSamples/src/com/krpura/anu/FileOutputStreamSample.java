package com.krpura.anu;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamSample {

	//supplier.txt
	FileOutputStream fos;
	String str = "We are writing this data to a File thru Binary STream";
	byte mybytes[] = new byte[100];
	public void writeToBinaryStream()
	{
		try {
			fos = new FileOutputStream("supplier.txt");
			mybytes = str.getBytes();
			fos.write(mybytes);//binary
			fos.flush();
			fos.close();
			System.out.println("We have written binary data into a file thru binary op stream");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  catch (IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileOutputStreamSample fops = new FileOutputStreamSample();
		fops.writeToBinaryStream();

	}

}
