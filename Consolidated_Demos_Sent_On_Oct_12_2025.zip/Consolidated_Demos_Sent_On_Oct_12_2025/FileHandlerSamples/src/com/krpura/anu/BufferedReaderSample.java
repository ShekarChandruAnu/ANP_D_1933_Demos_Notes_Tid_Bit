package com.krpura.anu;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class BufferedReaderSample {
	BufferedReader br;
	public void readFromCharStreamUsingBuffer()
	{
		try {
			br = new BufferedReader(new FileReader("student.txt"));
			String str = br.readLine();
			System.out.println("The Data Read from Char Stream using Buffer :"+str);
			br.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BufferedReaderSample brs = new BufferedReaderSample();
		brs.readFromCharStreamUsingBuffer();

	}

}
