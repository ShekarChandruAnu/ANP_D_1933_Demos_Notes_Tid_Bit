package com.krpura.anu;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferedOutputStreamSample {

	BufferedOutputStream bos;
	String str = "We are writing to Binary STream through Buffer";
	byte myByte[] = new byte[100];
	public void writeToBinaryStreamThruBuffer()
	{
		//FileOutputStream fos = new FileOutputStream("dealer.txt");
		try {
			myByte = str.getBytes();
		//	bos = new BufferedOutputStream(new FileOutputStream("dealer.txt"),100000);
			bos = new BufferedOutputStream(new FileOutputStream("dealer.txt"));
			bos.write(myByte);
			bos.flush();
			bos.close();
			System.out.println("We wrote to binary stream successfully thru Buffer");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		} // 100 Kb -- Buffer 10Kb
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedOutputStreamSample bos = new BufferedOutputStreamSample();
		bos.writeToBinaryStreamThruBuffer();

	}

}
