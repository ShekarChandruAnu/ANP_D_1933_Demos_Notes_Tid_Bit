package com.krpura.anu;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class SerializerSample {

	ObjectOutputStream ops;
	public void serializeObjects()
	{
		ArrayList <Customer> customers = new ArrayList<Customer>();
		customers.add(new Customer("C001","Sumanth","9839939933","Indiranagar",20000,1234.45f));
		customers.add(new Customer("C002","Suman","9839789657","Vijayanagar",25000,1354.45f));
		customers.add(new Customer("C003","Mahesh","9839939873","Koramangala",20000,1234.45f));
		customers.add(new Customer("C004","Sreedhar","9839956333","Malleswaram",20000,1234.45f));
		customers.add(new Customer("C005","Srinivas","6699399343","Koramangala",20000,1234.45f));
		try {
			ops = new ObjectOutputStream(new FileOutputStream("buyers.txt"));
			ops.writeObject(customers);
			ops.flush();
			ops.close();
			System.out.println("We Serialized the Customer Objects Successfully...");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		SerializerSample srlzrsample = new SerializerSample();
		srlzrsample.serializeObjects();

	}

}
