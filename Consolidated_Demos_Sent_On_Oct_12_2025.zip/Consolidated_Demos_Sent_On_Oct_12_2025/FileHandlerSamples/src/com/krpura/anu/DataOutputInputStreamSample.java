package com.krpura.anu;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class DataOutputInputStreamSample {

	DataOutputStream dos;
	DataInputStream dis;
	
	public void writeToDataOutputStream()
	{
		try {
			dos = new DataOutputStream(new FileOutputStream("employee.txt"));
			dos.writeDouble(2345.678);
			dos.writeUTF("welcome to DataStreams");
			dos.writeFloat(345.567f);
			dos.writeInt(20000);
			dos.writeBoolean(true);
			dos.flush();
			dos.close();
			// typeOf
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void readFromDataINputStream()
	{
		try {
			dis = new DataInputStream(new FileInputStream("employee.txt"));
			System.out.println("The Data Read in Original Format through DataStreams .....");
			System.out.println("The Double Data "+dis.readDouble());
			System.out.println("The UTF Data "+dis.readUTF());
			System.out.println("The Float  Data "+dis.readFloat());
			System.out.println("The Int data "+dis.readInt());
			System.out.println("The Boolean Data "+dis.readBoolean());
			dis.close();
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DataOutputInputStreamSample doss = new DataOutputInputStreamSample();
		doss.writeToDataOutputStream();
		doss.readFromDataINputStream();

	}

}
