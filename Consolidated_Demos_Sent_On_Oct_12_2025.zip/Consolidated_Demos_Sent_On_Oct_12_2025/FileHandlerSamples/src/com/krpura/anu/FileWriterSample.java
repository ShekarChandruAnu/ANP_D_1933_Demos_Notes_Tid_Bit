package com.krpura.anu;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriterSample {

	FileWriter fw;
	String str = "we are writing the char data into a file thru char stream";
	public void writeToCharStream()
	{
		try {
			fw = new FileWriter("customer.txt");
			fw.write(str);
			fw.flush();
			fw.close();
			System.out.println("We successfully wrote to char stream");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileWriterSample fws = new FileWriterSample();
		fws.writeToCharStream();

	}

}
