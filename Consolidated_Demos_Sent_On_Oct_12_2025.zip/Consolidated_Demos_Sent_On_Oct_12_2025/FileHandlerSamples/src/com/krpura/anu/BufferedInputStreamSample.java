package com.krpura.anu;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class BufferedInputStreamSample {

	byte mybytes[] = new byte[100];
	BufferedInputStream bis;
	public void readFromBinaryStreamThruBuffer()
	{
		try {
			bis = new BufferedInputStream(new FileInputStream("dealer.txt"));
			bis.read(mybytes);
			String str = new String(mybytes);
			
			bis.close();
			System.out.println("The Data Read thru Buffer from Binary Stream "+str);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedInputStreamSample bis = new BufferedInputStreamSample();
		bis.readFromBinaryStreamThruBuffer();

	}

}
