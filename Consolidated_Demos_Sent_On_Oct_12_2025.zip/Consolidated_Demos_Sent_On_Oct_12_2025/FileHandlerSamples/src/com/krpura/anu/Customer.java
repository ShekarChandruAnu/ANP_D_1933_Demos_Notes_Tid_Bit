package com.krpura.anu;

import java.io.Serializable;

public class Customer implements Serializable{
	
	String customerId;
	String customerName;
	String customerPhone;
	String customerAddress;
	int purchaseValue;
	transient float salesTax;
	
	/*
	 * Non ACcess Modifiers :static final abstract transient volatile synchronized
	 * AccessModifiers : Private public protected default
	 */
	/*
	 * Constructor/Overloaded Constructor/Getters/Setters/toString()
	 */
	public Customer() {
		super();
	}

	public Customer(String customerId, String customerName, String customerPhone, String customerAddress,
			int purchaseValue, float salesTax) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerPhone = customerPhone;
		this.customerAddress = customerAddress;
		this.purchaseValue = purchaseValue;
		this.salesTax = salesTax;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public int getPurchaseValue() {
		return purchaseValue;
	}

	public void setPurchaseValue(int purchaseValue) {
		this.purchaseValue = purchaseValue;
	}

	public float getSalesTax() {
		return salesTax;
	}

	public void setSalesTax(float salesTax) {
		this.salesTax = salesTax;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerPhone="
				+ customerPhone + ", customerAddress=" + customerAddress + ", purchaseValue=" + purchaseValue
				+ ", salesTax=" + salesTax + "]";
	}
	
	
	
	
	
	

}
