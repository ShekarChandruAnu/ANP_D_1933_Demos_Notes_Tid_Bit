package com.krpura.anu;

import java.io.BufferedInputStream;
import java.io.IOException;

public class BufferedInputStreamKbd {

	BufferedInputStream bis;
	byte mybytes[] = new byte[100];
	public void readFromKeyBoardThruBufferedStream()
	{
		bis = new BufferedInputStream(System.in);
		System.out.println("Enter some text thru Kbd...");
		try {
			bis.read(mybytes);
			String str = new String(mybytes);
			System.out.println("The Data Read from KBD thru Buffered Stream... "+str);
			bis.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedInputStreamKbd bisk = new BufferedInputStreamKbd();
		bisk.readFromKeyBoardThruBufferedStream();
	}

}
