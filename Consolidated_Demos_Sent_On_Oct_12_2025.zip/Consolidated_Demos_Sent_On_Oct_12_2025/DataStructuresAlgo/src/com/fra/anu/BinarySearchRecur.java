package com.fra.anu;

public class BinarySearchRecur {

	int mid;
	public int binsearch(int arr[],int key,int low,int high)
	{								//0   1   2  3 4 5
		mid = (low + high)/2;		//[10 20 30 40 50 60]   5+0/2 = 2
		if(arr[mid] == key)
		{
			return mid;
		}
		if(low == high)
		{
			return -1;
		}
		if(arr[mid] > key)
		{
			return binsearch(arr,key,low,mid-1);
		}
		if(arr[mid] < key)
		{
			return binsearch(arr,key,mid+1,high);
		}
		return -1;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {10,20,30,40,50,60};
		BinarySearchRecur bsr = new BinarySearchRecur();
		int indexFound = bsr.binsearch(arr, 50, 0, 5); // l h
		if(indexFound == -1)
		{
			System.out.println("Sorry Did nt find the Key");
		}
		else
		{
			System.out.println("Found key at index :"+(indexFound+1));
		}
		
	}

}
