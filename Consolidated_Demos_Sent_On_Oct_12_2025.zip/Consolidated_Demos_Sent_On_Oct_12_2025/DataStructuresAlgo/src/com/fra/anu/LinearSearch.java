package com.fra.anu;

public class LinearSearch {

	// 0 to size-1
	public int linearSearch(int arr[],int size,int target)
	{
		for(int i=0;i<size;i++)  //O(n)
		{
			if(arr[i] == target)
			{
				return i;
			}
		}
		return -1;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[] = {78,45,67,32,89,90,12};
		int nSize = arr.length;
		int x =167;
		LinearSearch ls = new LinearSearch();
		int indexFound = ls.linearSearch(arr, nSize, x);
		if(indexFound == -1)
		{
			System.out.println("Sorry The Element was not Found...");
		}
		else
		{
			System.out.println("The Element was found in the Index "+(indexFound+1));
		}
		
	}

}
