package com.fra.anu;

import java.util.Scanner;

public class BinarySearch {
		//       10           67   0   9 4				
	public int num_elements, value, l, r,mid;
	Scanner scan = new Scanner(System.in);
	public int array[];
	
	public void implementBinSearch()
	{
		System.out.println("Enter the number of elements you wish to store ");
		num_elements = scan.nextInt();
		array = new int[num_elements];
		insertValues();
		System.out.println("Enter the value you wish to search..");
		value = scan.nextInt();
		searchValue();
	}
	public void insertValues()
	{
		for(int i=0;i<num_elements;i++)
		{
			System.out.println("Enter the element of position "+i+" :");
			array[i] = scan.nextInt();
		}
	}
	public void searchValue()
	{
		l = 0;
		r = array.length - 1; // 6 -  0 to 5
		mid = l + (r - l) / 2; //  0 + ( 5-0)/2  --> 0 + 5 / 2 --> 0 + 2.5--> 2
		// O(log n)
		while(l <= r)							//	0	       4				9
		{							//int arr[] = {10,20,30,40,50,60,80,90,100,110};
			if (value < array[mid])				//  l			m				r
			{
				r = mid - 1;			//		l + (r - l) / 2; -- > 5 +(4)/2--7
			}
			else if(value > array[mid])
			{
				l = mid + 1;
			}
			else
			{
				System.out.println("Search Value "+value+"Found at Index"+mid);
				break;
			}
			mid = l + (r - l) / 2;
		}
		if( l > r)
		{
			System.out.println("Sorry Value Not found..");
		}
	}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BinarySearch bs  = new BinarySearch();
		bs.implementBinSearch();

	}

}
