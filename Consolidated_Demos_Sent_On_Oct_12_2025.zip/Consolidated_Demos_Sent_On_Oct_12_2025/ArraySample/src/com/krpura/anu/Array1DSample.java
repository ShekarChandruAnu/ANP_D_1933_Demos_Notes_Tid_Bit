package com.krpura.anu;

// EmployeeDetails OK
// employeedetails not ok
public class Array1DSample {

	int numbers[] = new int[10];
	//int studentScore[][] = new int[4][4];
	
	// methods and variable lower camel case
	// employeeName OK
	//EmployeeName not ok
	//getEmployeeDetails() OK
	//GETEMPLOYEEDETAILS 
	//This method enables us to Manipulate 1 Dim array
	public void manipulate1DArray()
	{
		for(int i=0;i<10;i++)
		{
			numbers[i] = (i+1)*100;
			System.out.println("The ARray Element is "+numbers[i]);
		}
	}
	public void manipulate2DArray()
	{
		int studentScore[][] = {{78,79,80,82},
								{85,82,84,83},
									{67,68,69,61}};
		
		
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<4;j++)
			{
				System.out.print(studentScore[i][j]+" ");
			}
			System.out.println();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Array1DSample a1ds = new Array1DSample();
		//a1ds.manipulate1DArray();
		a1ds.manipulate2DArray();

	}

}
