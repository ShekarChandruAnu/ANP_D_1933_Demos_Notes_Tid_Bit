package com.krpura.anu;

public class VarArgsSample {
	
	public void calculateAverage(String eName,int score1,int score2,int score3)
	{
		double average=(score1+score2+score3)/3;
		System.out.println("Hi "+eName+" Your Average score is "+average);
	}
	// ... called as ellipses
	//Following method has var args
	//after a STring any number of integer parameters can be supplied
	//RULE 1 : you can have only one var args in a Method
	//RULE 2: it can be of any type
	//RULE 3: var args should be at the end only
	//RULE 4 : var args are object of ARRAY class
	//ARray Class has a Property length
	public void calculateAverageNew(String eName,int... scores)
	{ // 87 88 90 92        93 91 90 78 87
		double average;
		int total=0;
		for(int x : scores)
		{
			total = total + x; // total = 0 + 87 -- total  = 87+88  --total --175+90--total=265+92
		}
		average = total / scores.length;
		System.out.println("Hi "+eName+" Your Average is "+average);
		System.out.println("------");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VarArgsSample vars = new VarArgsSample();
		vars.calculateAverage("Kiran ",87,89,90);
		vars.calculateAverageNew("Kishan ",87,89,90,85);
		vars.calculateAverageNew("Keerthana ",87,89,90,92,93);
		vars.calculateAverageNew("Suman ",87,89,90,82);

	}

}
