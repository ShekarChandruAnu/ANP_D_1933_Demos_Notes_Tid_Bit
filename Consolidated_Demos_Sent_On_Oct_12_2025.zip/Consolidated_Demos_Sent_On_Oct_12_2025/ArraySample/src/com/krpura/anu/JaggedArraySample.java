package com.krpura.anu;

public class JaggedArraySample {
	
	int jagArr[][] = new int[3][];
	public void manipulateJaggedArray()
	{
		jagArr[0] = new int[5];// 0th row has 5 columns
		jagArr[1] = new int[7]; // 1st row has 7 columns
		jagArr[2] = new int[3]; // 2nd row has 3 columns
		
		for(int i=0;i<5;i++)
		{
			jagArr[0][i] = (i+1)*100;
			System.out.print(jagArr[0][i]+" ");
		}
		System.out.println();
		for(int j=0;j<7;j++)
		{
			jagArr[1][j] = (j+1)* 1000;
			System.out.print(jagArr[1][j]+ " ");
		}
		System.out.println();
		for(int k=0;k<3;k++)
		{
			jagArr[2][k] = (k+1)*10000;
			System.out.print(jagArr[2][k]+" ");
 		}
	
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JaggedArraySample jars = new JaggedArraySample();
		jars.manipulateJaggedArray();
	}

}
