package com.krpura.anu;

public class ArraySampleNew {

	int[] arr = new int[10]; //
	int[][] arr1 = new int[3][4];
	public void manipulateArray()
	{
		for(int i=0;i<10;i++)
		{
			arr[i] = (i+1)*1000;
		}
	}
	public void displayArrayElements()
	{
		//Fast Enumeration which is faster than the for loop
		for(int x :arr)
		{
			System.out.println("The Element is "+x);
		}
	}
	public void populate2DArray()
	{
		for(int i=0;i<3;i++)//rows
		{
			for(int j=0;j<4;j++)//columns
			{
				arr1[i][j] = (i+j)*100;
				System.out.print(arr1[i][j]+" ");
			}
			System.out.println();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArraySampleNew asn = new ArraySampleNew();
	/*	asn.manipulateArray();
		asn.displayArrayElements();*/
		asn.populate2DArray();
		//asn.displayArrayElements();
	}

}
