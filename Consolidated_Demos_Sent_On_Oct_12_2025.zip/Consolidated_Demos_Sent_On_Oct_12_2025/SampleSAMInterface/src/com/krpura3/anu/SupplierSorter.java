package com.krpura3.anu;

import java.util.ArrayList;
import java.util.Collections;

public class SupplierSorter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList <Supplier> suppliers = new ArrayList<Supplier>();
		suppliers.add(new Supplier("S004","Chandan","Jodhpur",8000));
		suppliers.add(new Supplier("S006","Emanuel","Ahmedabad",10000));
		suppliers.add(new Supplier("S001","David","Nagpur",9000));
		suppliers.add(new Supplier("S003","Amarendra","Agra",9800));
		suppliers.add(new Supplier("S005","Faheem","Delhi",8500));
		suppliers.add(new Supplier("S003","BasuChaterjee","Balasore",7000));
		// sorting supplierId
		System.out.println("-----Sorting Supplier ID------");
		Collections.sort(suppliers, (s1,s2) -> { return s1.getSupplierId().compareTo(s2.getSupplierId()); } );
		for(Supplier s : suppliers)
		{
			System.out.println("The Supplier "+s);
		}
		//Sorting supplierName
		System.out.println("-----Sorting Supplier Name------");
		Collections.sort(suppliers,(s1,s2) ->{return s1.getSupplierName().compareTo(s2.getSupplierName()) ; });
		for(Supplier s : suppliers)
		{
			System.out.println("The Supplier "+s);
		}
		System.out.println("-----Sorting Supplier City------");
		Collections.sort(suppliers,(s1,s2) ->{return s1.getSupplierCity().compareTo(s2.getSupplierCity()) ; });
		for(Supplier s : suppliers)
		{
			System.out.println("The Supplier "+s);
		}
		System.out.println("-----Sorting Supplier SupplyValue------");
		Collections.sort(suppliers,(s1,s2) ->{return Integer.compare(s1.getSupplyValue(), s2.getSupplyValue());});
		for(Supplier s : suppliers)
		{
			System.out.println("The Supplier "+s);
		}
	}

}
