package com.krpura.anu;



//FUNCTIONAL INTERFACE DEFINITION
@FunctionalInterface
interface MyInterface
{
	public void display();
	//public void display1();
}
interface InvoiceCalculator
{
	public void calculateInvoiceAmt(int price, int qty);
}


public class FunctionalInterfaceSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//FUNCTIONAL INTERFACE - SAM IMPLEMENTED WITH THE HELP OF LAMBDA EXPRESSION
		MyInterface mint1 = () -> { 
			System.out.println(" We are Implementing Functional Interfaces...");
		};
		
		//INVOKING THE METHOD OF FUNCTIONAL INTERFACE THROUGH REFERENCE
		mint1.display();
		
		InvoiceCalculator iCalci1 = (int pPrice,int pQty) -> {
			
			int invoiceAmount = pPrice * pQty;
			System.out.println("The Invoice AMount is "+invoiceAmount);
			if( invoiceAmount > 100000)
			{
				System.out.println("Good Sale...");
			}
			else
			{
				System.out.println("Moderate Sale...");
			}
			
		};
		
		
		
	}

}
