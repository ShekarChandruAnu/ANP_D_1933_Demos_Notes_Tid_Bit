package com.krpura2.anu;

@FunctionalInterface
interface Customer
{
	public double calculateInvoice(int pricePerUnit,int quantity);
}

@FunctionalInterface
interface SalesData
{
	public void analyzeSales(int pricePerUnit,int quantity,Customer customer);
}
public class FunctionalInterfaceSample2 {
	
	public static void main(String[] args)
	{
		
		Customer cust1 = (int pPrice,int pQty) -> {
			//Discount 10%
			int originalInvAmount = pPrice * pQty;
			double discountedInvAmount = originalInvAmount - (0.1 * originalInvAmount);
			return discountedInvAmount;
		};
		
		Customer cust2 = (int pPrice1,int pQty1) -> {
			//Discount 20%
			int originalInvAmount = pPrice1 * pQty1;
			double discountedInvAmount = originalInvAmount - (0.2 * originalInvAmount);
			return discountedInvAmount;
		};
		
		SalesData sData1 = (int price,int qty,Customer customer)->{
			
			int originalInvoiceAmt = price * qty;
			
			double discountedInvoiceAmt = customer.calculateInvoice(price, qty);
			System.out.println("The Original Invoice AMount is "+originalInvoiceAmt);
			System.out.println("The Discounted Invoice AMount is "+discountedInvoiceAmt);
			
		};
		
		sData1.analyzeSales(1000,100,cust1);
		System.out.println("--------");
		sData1.analyzeSales(1000, 100, cust2);
		
		
	}

}
