package com.krpura1.anu;

//Name of the Functional Interface : MyInterface
//Method it Contains : display()
@FunctionalInterface
interface MyInterface
{
	public void display();
	
}
//Name of the Functional Interface : InvoiceCalculator
//Method it contains: calculateInvoice()
@FunctionalInterface
interface InvoiceCalculator
{
	public void calculateInvoiceAmt(int price,int quantity);
}

public class FunctionalInterfaceSample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//--------------------FUNCTIONAL INTERFACE -MyINTERFACE IMPLEMENTATION STARTED-------
		//LAMBDA EXPRESSION TO IMPLEMENT THE FUNCTIONAL INTERFACE MyInterface
		//Through which we are implementing the method of the MyInterface - FInterface : display
		MyInterface mint1 = () -> {
			System.out.println("We are implementing method display");
		};
		//mint1 is the reference of the FUNCTIONAL INTERFACE - called MyInterface
		//which hold the reference of the Method display 
		
		//Invoking the method of the Functional Interface - MyInterface 's method called display
		mint1.display();
		//--------------------FUNCTIONAL INTERFACE -MyINTERFACE IMPLEMENTATION COMPLETED-------
		
		//--------------------FUNCTIONAL INTERFACE -InvoiceCalculator IMPLEMENTATION STARTED-------
		
		InvoiceCalculator iCalci1 = (int pPrice,int pQty) ->{
			
			int invoiceAmount = pPrice * pQty;
			if(invoiceAmount > 100000)
			{
				System.out.println("Hey!!! Good Sale...");
			}
			else
			{
				System.out.println("OK!!! Moderate Sale...");
			}
		};
		System.out.println(" The First Implementation of calculateInvoiceAmt  method called for condition1");
		iCalci1.calculateInvoiceAmt(1000, 110);
		System.out.println(" The First Implementation of calculateInvoiceAmt  method called for condition2 ");
		iCalci1.calculateInvoiceAmt(500, 100);
		System.out.println("------------");
		InvoiceCalculator iCalci2 = (int pPrice,int pQty) ->{
			
			int invoiceAmount = pPrice * pQty;
			if(invoiceAmount > 50000)
			{
				System.out.println("Hey!!! Good Sale...");
			}
			else
			{
				System.out.println("OK!!! Moderate Sale...");
			}
		};
		System.out.println(" The Second Implementation of calculateInvoiceAmt  method called for condition1");
		iCalci2.calculateInvoiceAmt(500, 110);
		System.out.println(" The Second Implementation of calculateInvoiceAmt  method called for condition2");
		iCalci2.calculateInvoiceAmt(400, 100);
		
		//--------------------FUNCTIONAL INTERFACE -InvoiceCalculator IMPLEMENTATION COMPLETED-------
		
	}

}
