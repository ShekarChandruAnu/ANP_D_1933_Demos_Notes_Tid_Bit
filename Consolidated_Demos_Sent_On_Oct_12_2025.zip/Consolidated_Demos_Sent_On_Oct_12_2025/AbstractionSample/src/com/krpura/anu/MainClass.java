package com.krpura.anu;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Shapes myShapes;
		
		myShapes = new Rectangle();// ALLOWED
		myShapes.draw();
		
		myShapes = new Triangle(); /// ALLOWED
		myShapes.draw();
		
	//	Triangle triangle = new Shapes(); ??? IS IT ALLOWED NO
		
		// Shapes  myShape = new Shapes(); ABSTRACT CLASS CANNOT BE INSTANTIATED 
	//	Shapes obj = new Rectangle();

	}

}
