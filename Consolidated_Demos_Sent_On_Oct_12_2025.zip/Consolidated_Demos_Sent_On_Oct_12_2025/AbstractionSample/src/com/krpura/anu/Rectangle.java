package com.krpura.anu;

public class Rectangle extends Shapes{

	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("The Rectangles are drawn....");
		
	}

}
