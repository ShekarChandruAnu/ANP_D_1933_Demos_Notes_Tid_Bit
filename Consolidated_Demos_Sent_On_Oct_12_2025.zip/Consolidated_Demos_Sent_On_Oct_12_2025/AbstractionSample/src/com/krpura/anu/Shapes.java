package com.krpura.anu;

public abstract class Shapes {
	
	public abstract void draw();
	public void displayData()
	{
		System.out.println("Displaying data");
	}
	

}
