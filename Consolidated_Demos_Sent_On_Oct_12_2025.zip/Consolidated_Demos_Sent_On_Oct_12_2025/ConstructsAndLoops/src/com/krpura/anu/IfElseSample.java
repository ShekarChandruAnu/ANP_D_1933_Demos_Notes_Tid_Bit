package com.krpura.anu;

public class IfElseSample {

	//IF .. else Construct
	// Constructs take the course of action of a Program
	// in  a certain direction based on the condition
	public void checkScore(int score)
	{
		if(score >= 50)
		{
			System.out.println("Good Passed ");
		}
		else
		{
			System.out.println("Sorry Try AGain");
		}
	}
	public void checkScoreIfElseIf(int score)
	{
		//0 100
	if((score >= 0) && (score <= 100))
	{
		if((score >= 50) && (score < 60)) //50 to 59
		{
			System.out.println("Good Passed...");
		}
		else if((score >= 60) && (score < 70)) // 60 to 69
		{
			System.out.println("V Good First Class");
		}
		else if((score >= 70) && (score <= 100)) // 70 to 100
		{
			System.out.println("Excellent Secured Distinction Class");
		}
		else
		{
			System.out.println("Sorry Try again");
		}
	}
	else
	{
		System.out.println("Sorry Valid score is 0-100");
	}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IfElseSample ifsam = new IfElseSample();
		ifsam.checkScore(75);
		ifsam.checkScoreIfElseIf(45);
		ifsam.checkScoreIfElseIf(55);
		ifsam.checkScoreIfElseIf(65);
		ifsam.checkScoreIfElseIf(75);
		ifsam.checkScoreIfElseIf(-175);

	}

}
