package com.krpura.anu;

import java.util.Scanner;

public class WhilerSample {

	Scanner scan1 = new Scanner(System.in);
	public void whileCheck()
	{
		String reply="yes";
		int num1;
		int square;
		while(reply.equals("Yes") || reply.equals("yes"))
		{
			System.out.println("Enter the Number ..");
			num1 = scan1.nextInt();
					// break n continue
			if(num1 > 100)
			{
				System.out.println("Sorry , Number to be in the Range 1-100");
			//	break;
				continue;
			}
			square = num1 * num1;
			System.out.println("The Number is"+num1);
			System.out.println("The Square of your Number is "+square);
			System.out.println("Do You wish to Continue yes /no ");
			reply = scan1.next();
		}
		System.out.println("We are out of loop");
	}
	public void doWhileCheck()
	{
		String reply="";
		int num1;
		int square;
		do 
		{
			System.out.println("Enter the Number ..");
			num1 = scan1.nextInt();
					// break n continue
			if(num1 > 100)
			{
				System.out.println("Sorry , Number to be in the Range 1-100");
			//	break;
				continue;
			}
			square = num1 * num1;
			System.out.println("The Number is"+num1);
			System.out.println("The Square of your Number is "+square);
			System.out.println("Do You wish to Continue yes /no ");
			reply = scan1.next();
		}while(reply.equals("Yes") || reply.equals("yes"));
		
		System.out.println("We are out of loop");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WhilerSample ws = new WhilerSample();
		//ws.whileCheck();
		ws.doWhileCheck();
	}

}
