package com.krpura.anu;

public class SwitcherSample {

	public void switchDay(int day)
	{
		switch(day)
		{
			case 1:
			{
				System.out.println("Day Is Sunday..");
				break;
			}
			case 2:
			{
				System.out.println("Day Is Monday..");
				break;
			}
			case 3:
			{
				System.out.println("Day Is Tuesday..");
				break;
			}
			case 4:
			{
				System.out.println("Day Is Wednesday..");
				break;
			}
			case 5:
			{
				System.out.println("Day Is Thursday..");
				break;
			}
			case 6:
			{
				System.out.println("Day Is Friday..");
				break;
			}
			case 7:
			{
				System.out.println("Day Is Saturday..");
				break;
			}
			default:
			{
				System.out.println("Sorry Valid Range is 1-7.");

			}
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SwitcherSample ssample = new SwitcherSample();
		ssample.switchDay(4);
		ssample.switchDay(5);
		ssample.switchDay(6);
		ssample.switchDay(7);
		ssample.switchDay(145);

	}

}
