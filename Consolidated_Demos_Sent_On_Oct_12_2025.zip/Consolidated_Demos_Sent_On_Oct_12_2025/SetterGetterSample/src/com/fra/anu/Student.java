package com.fra.anu;

public class Student {

	private String studentName;
	private int studentScore;
	
	public Student()
	{
		
	}
	//Setters for studentName
	public void setStudentName(String studentName)
	{
		this.studentName = studentName;
	}
	//Getter for studentName
	public String getStudentName()
	{
		return studentName;
	}
	
	//Setter for score
	public void setStudentScore(int studentScore)
	{
		this.studentScore=studentScore;
	}
	public int getStudentScore()
	{
		return studentScore;
	}
	public void displayStudentDetails()
	{
		System.out.println("Student Name "+studentName+" And Score is "+studentScore);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student student1 = new Student();
		student1.setStudentName("Harsha");
		student1.setStudentScore(89);
		student1.displayStudentDetails();
		
		System.out.println("The StudentName is "+student1.getStudentName());
		System.out.println("The Student Score is "+student1.getStudentScore());
		

	}
	
	

}
