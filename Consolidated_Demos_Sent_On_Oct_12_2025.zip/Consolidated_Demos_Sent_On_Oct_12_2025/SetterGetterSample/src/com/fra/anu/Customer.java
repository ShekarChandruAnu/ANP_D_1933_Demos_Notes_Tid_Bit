package com.fra.anu;

public class Customer {

	String customerId;
	String customerName;
	String customerAddress;
	int purchaseValue;
	// super.method() instance of the parent class.   
	// this. instance of the current class
	public Customer() {
		super();// Invokes the Parent class Constructor
		
	}
	//Overloaded Constructor initializing all the data members
	public Customer(String customerId, String customerName, String customerAddress, int purchaseValue) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.purchaseValue = purchaseValue;
	}
	

	public Customer(String customerId, String customerName, String customerAddress) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
	}

	/*
	 * Constructor
	 * Overloaded Constructor
	 * Getters Setters
	 * toString()
	 */
	

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public int getPurchaseValue() {
		return purchaseValue;
	}

	public void setPurchaseValue(int purchaseValue) {
		this.purchaseValue = purchaseValue;
	}

public String toString()
	{
		String str = "Customer "+customerName+"  With an ID :"
				+customerId+" Residing at "+customerAddress+" Purchased Goods worth :"
				+purchaseValue;
		return str;
	}	/**/
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Customer c1 = new Customer();
		Customer customer1 = new Customer("C001","Suman","RTNagar",12000);
		System.out.println("Customer Details "+customer1);

	}
	

}
