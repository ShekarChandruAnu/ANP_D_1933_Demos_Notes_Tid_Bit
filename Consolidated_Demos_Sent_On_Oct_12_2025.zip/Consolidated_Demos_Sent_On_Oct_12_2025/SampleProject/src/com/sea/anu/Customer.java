package com.sea.anu;

public class Customer {
	
	public static void main(String[] args)
	{
		System.out.println("Hello Welcome to Java Programming..");
	}

}
