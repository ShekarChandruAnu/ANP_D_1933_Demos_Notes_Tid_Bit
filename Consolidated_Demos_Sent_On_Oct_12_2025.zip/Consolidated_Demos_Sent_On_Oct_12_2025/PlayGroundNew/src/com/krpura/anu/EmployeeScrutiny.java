package com.krpura.anu;
 class Employee//<------------ end 
{
	public void display()
	{
		
	}
	
}
class TestEngineer extends Employee
{

	@Override
	public void display() {
		// TODO Auto-generated method stub
		
	}
}
class SoftwareEngineer extends Employee
{
	@Override
	public void display()
	{
		
	}
}
public class EmployeeScrutiny {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	/*	Employee employee = new Employee();
		employee.display();
		SoftwareEngineer sEngr = new SoftwareEngineer();
		sEngr.display(); */
		
		Employee employee1 = new SoftwareEngineer();
			employee1.display();
			
			employee1 = new TestEngineer();
			employee1.display();
			
			SoftwareEngineer se = (SoftwareEngineer)new Employee();
			se.display();
	}

}
