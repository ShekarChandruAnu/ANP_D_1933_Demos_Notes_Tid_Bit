package com.krpura.anu;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BaseClass bc = new BaseClass();
		bc.display1();
		// bc.display2(); NOT ALLOWED
		
		DerivedClass dc = new DerivedClass();
		dc.display1();
		dc.display2();

	}

}
