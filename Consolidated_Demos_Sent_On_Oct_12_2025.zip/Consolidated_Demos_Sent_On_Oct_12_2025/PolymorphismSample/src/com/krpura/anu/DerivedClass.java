package com.krpura.anu;

public class DerivedClass extends BaseClass {

	public void display2()
	{
		System.out.println("Displaying the Derived Class Method : display2");
	}
}
