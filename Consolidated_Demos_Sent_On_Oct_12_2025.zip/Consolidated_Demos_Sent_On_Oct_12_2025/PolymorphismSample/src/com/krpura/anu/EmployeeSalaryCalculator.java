package com.krpura.anu;

public class EmployeeSalaryCalculator {

	// public void DisplaySalaryDetails()
	// public void displaySalaryDetails()
	// 
	
	double grossSalary;
	double nettSalary ;
	//method to calculate Gross Salary for the given Basic,Hra,CCa,allowances for a Particular Person
	public void calculateSalary(double basic, double hra,double cca,double allowances,String employeeName)
	{
		grossSalary = basic+hra+cca+allowances;
		System.out.println("The Gross Salary of "+employeeName+" is "+grossSalary);
	}
	public void calculateSalary(double basic, double hra,double cca,double allowances,double deductions,String employeeName)
	{
		double grossSal = basic+hra+cca+allowances;
		nettSalary = grossSal - deductions;
		System.out.println("The Gross Salary for "+employeeName+" Is "+grossSal+" And the Nett Salary is "+nettSalary);
	}
	public void calculateSalary(double basic, double hra,double cca,double allowances,double deductions,double bonus,String employeeName)
	{
		double grossSal = basic+hra+cca+allowances;
		nettSalary = grossSal - deductions;
		System.out.println("The Gross Salary for "+employeeName+" Is "+grossSal+" And the Nett Salary is "+nettSalary);
		double bonusAmount = (bonus / 100 )* grossSal;
		System.out.println("The Bonus amount is "+bonusAmount);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EmployeeSalaryCalculator esCalci = new EmployeeSalaryCalculator();
		System.out.println("Calling Overloaded Method with basic, hra,cca,allowance & Employee Name");
		esCalci.calculateSalary(10000.0, 250.0, 350.0, 1250.0, "Kiran Kumar");
		System.out.println("Calling Overloaded Method with basic, hra,cca,allowance,Deductions & Employee Name");
		//
		esCalci.calculateSalary(10000.0, 250.0, 350.0, 1250.0,975.0, "Mahesh Kumar");
		
		System.out.println("Calling Overloaded Method with basic, hra,cca,allowance,Deductions,Bonus Percentage & Employee Name");
		
		esCalci.calculateSalary(10000.0, 250.0, 350.0, 1250.0,975.0,11, "Sreedhar");

	}
	

}
