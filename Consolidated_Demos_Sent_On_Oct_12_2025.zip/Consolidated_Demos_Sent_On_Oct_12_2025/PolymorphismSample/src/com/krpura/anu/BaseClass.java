package com.krpura.anu;

public class BaseClass {
	
	public void display1()
	{
		System.out.println("Displaying the Base Class Method : display1 .....");
	}

}
