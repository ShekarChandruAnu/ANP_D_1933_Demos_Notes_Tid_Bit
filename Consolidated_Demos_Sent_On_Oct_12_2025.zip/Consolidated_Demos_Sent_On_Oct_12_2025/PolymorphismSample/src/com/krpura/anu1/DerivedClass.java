package com.krpura.anu1;

public class DerivedClass extends BaseClass{

	@Override
	public void display()
	{
		System.out.println("Calling Base class Display");
	}
	public void display2()
	{
		System.out.println("Displaying Derived Class");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DerivedClass dc = new DerivedClass();
		dc.display1();
		dc.display2();
		dc.display(); // AT THE TIME OF COMPILATION RESOLUTION IS NOT HAPPENED
	}

}
