package com.krpura.anu1;

public class BaseClass {
	public void display()
	{
		System.out.println("Calling Base Class display..");
	}

	public void display1()
	{
		System.out.println("Displaying Base Class...");
	}

}

