// File Name: Singleton.java
package com.fran.anu;
class Singleton 
{
private static Singleton singleton = new Singleton( );
	/* A private Constructor prevents any other
    	* class from instantiating.
    	*/
private Singleton() { }
/* Static 'instance' method */
 public static Singleton getInstance() 
{
      return singleton;
  }
/* Other methods protected by singleton-ness */
   protected static void demoMethod( )
 {
      System.out.println("demoMethod for singleton");
   }
}
//Here is the main program file where we will create a singleton object −
// File Name: SingletonDemo.java
public class SingletonDemo 
{
	public static void main(String[] args) 
	{
		//Singleton s1 = new Singleton();
     	 Singleton tmp = Singleton.getInstance( );
     	 tmp.demoMethod( );
     	 Singleton tmp1 = Singleton.getInstance();
     	 tmp1.demoMethod();
   	}
}
