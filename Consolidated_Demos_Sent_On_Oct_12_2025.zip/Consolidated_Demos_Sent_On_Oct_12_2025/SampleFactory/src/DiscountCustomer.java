
public class DiscountCustomer implements ICustomer
{

	@Override
	public void displayCustomer() {
		// TODO Auto-generated method stub
		System.out.println("Customer type is DISCOUNT CUSTOMER");
		
	}

}
