import java.util.Scanner;


public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner myScan1=new Scanner(System.in);
		
	/*	System.out.println("Enter the Customer Type");
		String customerType=myScan1.next();*/
		
		/*DiscountCustomer discount=new DiscountCustomer();
		discount.displayCustomer();*/
		
		String cType=args[0];
		//String cType="loyal";
		ICustomer myCustomer=CustomerFactory.createInstance(cType);
		myCustomer.displayCustomer();
		
		//Quality Statement
		//About The Design Patterns

	}

}
