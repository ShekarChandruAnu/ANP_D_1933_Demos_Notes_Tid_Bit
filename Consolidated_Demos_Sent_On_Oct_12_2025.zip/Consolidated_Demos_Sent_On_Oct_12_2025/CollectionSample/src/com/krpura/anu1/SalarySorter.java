package com.krpura.anu1;

import java.util.Comparator;

public class SalarySorter implements Comparator <Employee>{

	//Sorting salary an Integer field
	@Override
	public int compare(Employee employee1, Employee employee2) {
		// TODO Auto-generated method stub
		if (employee1.getEmpSalary() > employee2.getEmpSalary())
		{
			return 1;
		}
		else if (employee1.getEmpSalary() < employee2.getEmpSalary())
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}

}
