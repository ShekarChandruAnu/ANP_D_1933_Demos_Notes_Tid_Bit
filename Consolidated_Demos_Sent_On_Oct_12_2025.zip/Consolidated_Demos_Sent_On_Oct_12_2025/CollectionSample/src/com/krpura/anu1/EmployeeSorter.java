package com.krpura.anu1;

import java.util.ArrayList;
import java.util.Collections;

public class EmployeeSorter {

	public void sortEmployees()
	{
		ArrayList <Employee> employees = new ArrayList<Employee>();
		employees.add(new Employee("E002","Chandan","Fatehpur",15000));
		employees.add(new Employee("E004","Emanuel","Chandigarh",12000));
		employees.add(new Employee("E001","Zeenat","Bangalore",10000));
		employees.add(new Employee("E003","David","Ahmedabad",18000));
		//IdSorter ids = new IdSorter();
		Collections.sort(employees,new IdSorter());
		for(Employee e:employees)
		{
			System.out.println(e);
		}
		System.out.println("Employees Sorted based on Salary...");
		
		Collections.sort(employees,new SalarySorter());
		for(Employee e:employees)
		{
			System.out.println(e);
		}
		
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeSorter eSorter = new EmployeeSorter();
		eSorter.sortEmployees();

	}

}
