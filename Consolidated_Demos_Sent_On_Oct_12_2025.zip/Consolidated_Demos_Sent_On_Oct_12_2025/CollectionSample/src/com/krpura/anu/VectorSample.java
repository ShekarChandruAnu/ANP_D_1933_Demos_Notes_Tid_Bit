package com.krpura.anu;

import java.util.Enumeration;
import java.util.Vector;

public class VectorSample {
// 5 is initial size	
	// 2 It Grows By 2 
	Vector <Employee> myVector = new Vector<>(5,3);
	/*
	 * ALGORITHM IS PREDEFINED 5 3 8 + +
	 * 					5 9    4
	 */
	public void populateVector()
	{
		myVector.addElement(new Employee("E001","Mallesh Kumar","Jayanagar","9393993939",12000));
		myVector.addElement(new Employee("E002","Kishan Kumar","Malleswaram","7648939939",12000));
		myVector.addElement(new Employee("E003","Keerthana","Koramangala","7648936459",13000));
		myVector.addElement(new Employee("E004","Mohan Kumar","Indiranagar","7646579939",14000));
		myVector.addElement(new Employee("E005","Sreedhar","Koramangala","7631239939",16000));
		System.out.println("The Size of the Vector is "+myVector.size()); // 5
		System.out.println("The Capacity of the Vetcor is "+myVector.capacity()); //5
		myVector.addElement(new Employee("E006","Keerthana","Koramangala","7645339939",16000));
		myVector.addElement(new Employee("E007","Somanna","Koramangala","7631265739",17000));
		myVector.addElement(new Employee("E008","Puneeth","Koramangala","7321239939",16500));
		System.out.println("The Size of the Vector is "+myVector.size()); // 8
		System.out.println("The Capacity of the Vector is "+myVector.capacity()); // 8
		myVector.addElement(new Employee("E009","Rakshith","Malleswaram","5421239939",16500));
		System.out.println("The Size of the Vector is "+myVector.size());
		System.out.println("The Capacity of the Vector is "+myVector.capacity());
		myVector.addElement(new Employee("E010","VRakshith","Malleswaram","5421237839",16500));
		myVector.addElement(new Employee("E011","CRakshith","Malleswaram","5421234539",16500));
		System.out.println("The Size of the Vector is "+myVector.size());
		System.out.println("The Capacity of the Vector is "+myVector.capacity());
		myVector.addElement(new Employee("E012","KRakshith","Malleswaram","5321234539",16500));
		System.out.println("The Size of the Vector is "+myVector.size());
		System.out.println("The Capacity of the Vector is "+myVector.capacity());
	}
	public void fetchVectorElements()
	{
	Enumeration <Employee> vectorEnumer = myVector.elements();
		while(vectorEnumer.hasMoreElements()) // hasNext()
		{
			Employee employee = vectorEnumer.nextElement(); // next()
			System.out.println(employee);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		VectorSample vSample = new VectorSample();
		vSample.populateVector();
		vSample.fetchVectorElements();

	}

}
