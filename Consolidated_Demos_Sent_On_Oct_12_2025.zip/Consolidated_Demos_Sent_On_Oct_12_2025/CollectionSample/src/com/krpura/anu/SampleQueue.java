package com.krpura.anu;

import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class SampleQueue {

	Queue <String> myQueue = new PriorityQueue<String>();
	public void populateQueue()
	{
		myQueue.add("Ahmedabad");
		myQueue.add("Bangalore");
		myQueue.add("Chennai");
		myQueue.add("Dhanbad");
		myQueue.add("Ernakulam");
	}
	public void fetchQueueElements()
	{
		System.out.println("The Size of the Queue is Before Iteration :"+myQueue.size());
		Iterator <String> myIter = myQueue.iterator();
		while(myIter.hasNext())
		{
			String queueItem = myIter.next();
			System.out.println("The Item in Queue is "+queueItem);
		}
		System.out.println("The Size of the Queue is After Iteration :"+myQueue.size());
	}
	public void fetchThruRemove()
	{
		/**/
		System.out.println("The Size of the Queue  Before Removal :"+myQueue.size());
		while(myQueue.isEmpty() == false)
		{
			String queueItem = myQueue.remove();
			System.out.println("The Queue Item that is removed is "+queueItem);
		}
		System.out.println("The Size of the Queue  After Removal :"+myQueue.size());
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SampleQueue sQueue = new SampleQueue();
		sQueue.populateQueue();
		sQueue.fetchThruRemove(); // Thru remove method
		System.out.println("----------------");
		sQueue.fetchQueueElements(); // thru Iterator - which does not remove the elements from the queue
		
		

	}

}
