package com.krpura.anu;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class StudentSorter {

	public void sortStudents()
	{
		ArrayList<Student> students = new ArrayList<Student>();
		students.add(new Student("S001","Suresh Kumar","Coimbatore",89));
		students.add(new Student("S005","Amarendra","Ahmedabad",92));
		students.add(new Student("S003","Emanuel","Faridabad",78));
		students.add(new Student("S004","Yasmeen","Ernakulam",59));
		students.add(new Student("S002","Brajesh","Dhanbad",68));
		
	//	Iterator iter = students.iterator();
		Collections.sort(students);
		
		for(Student student : students)
		{
			System.out.println(student);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentSorter sSorter = new StudentSorter();
		sSorter.sortStudents();

	}

}
