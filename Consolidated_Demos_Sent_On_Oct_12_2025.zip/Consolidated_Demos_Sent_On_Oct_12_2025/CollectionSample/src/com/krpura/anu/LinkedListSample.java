package com.krpura.anu;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListSample {

	//Ctrl + SHift + O
	LinkedList <Employee> emplList = new LinkedList<Employee>();
	
	public void populateLList()
	{
		emplList.add(new Employee("E001","Kishan Kumar","Malleswaram","7648939939",12000));
	//	
		emplList.add(new Employee("E002","Kishan Kumar","Malleswaram","7648939939",12000));
		emplList.add(new Employee("E003","Keerthana","Koramangala","7648936459",13000));
		emplList.add(new Employee("E004","Mohan Kumar","Indiranagar","7646579939",14000));
		emplList.add(new Employee("E005","Sreedhar","Koramangala","7631239939",16000));
		emplList.add( new Employee("E006","Michael","Vijayanagar","7648939879",15000));
		
		emplList.add(new Employee("E007","Madan","Vijayanagar","7786939879",15000));
	emplList.addFirst(new Employee("E001a","Madhu","Indiranagar","6484884848",25000));
		emplList.addLast(new Employee("E008","Madhura","Vijayanagar","5344884848",22000));	/**/
	}
	public void fetchLinkedListElements()
	{
		//Iterator empIter = emplList.iterator();
		System.out.println("the Employees in the Linked List are ");
		Iterator <Employee> empIter = emplList.iterator();
		while(empIter.hasNext())
		{
			//Employee employee = (Employee) empIter.next();
			Employee employee = empIter.next();
			System.out.println(employee);
		}
	}
	public void fetchElementsInDescendingOrder()
	{
		System.out.println("The Employees using Descending Iterator....");
			Iterator <Employee> empDescIter = emplList.descendingIterator();
			while(empDescIter.hasNext())
			{
				Employee employee = empDescIter.next();
				System.out.println(employee);
			}
			
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedListSample lls = new LinkedListSample();
		lls.populateLList();
		lls.fetchLinkedListElements();
		System.out.println("-----------");
		lls.fetchElementsInDescendingOrder();

	}

}
