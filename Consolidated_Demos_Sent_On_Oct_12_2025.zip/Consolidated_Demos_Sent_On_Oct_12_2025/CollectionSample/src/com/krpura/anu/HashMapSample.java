package com.krpura.anu;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class HashMapSample {
	
	HashMap <String,Integer> hMap = new HashMap<String,Integer>();
	
	public void populateHashMap()
	{
		hMap.put("E001",10000);
		hMap.put("E003",20000);
		hMap.put("E004",15000);
		hMap.put("E002",25000);
		hMap.put("E005",35000);
		hMap.put("E007",13000);
		hMap.put("E006",23000);
		hMap.put("E006",25000);
		hMap.put("E006",27000);
		hMap.put("E008",25000);
	}
	public void fetchHashMapObjectsThruKeySet()
	{
		//int x = obj.method1();
		Set <String> myKeys = hMap.keySet();
		System.out.println("--------Displaying Keys using for each loop----");
		for(String mykey:myKeys)
		{
			System.out.println("The Key is "+mykey+" And the Corresponding value is "+hMap.get(mykey));
		}
		hMap.remove("E005"); // Removes Key
		System.out.println("--------Displaying Keys & value susing for each loop----");
		Iterator <String> myKeyIter = myKeys.iterator();
		while(myKeyIter.hasNext())
		{
			String myKey = myKeyIter.next();
		Integer myValue = 	hMap.get(myKey);
		System.out.println("The Value for the Key :"+myKey+"  is "+myValue);
		}
	}
	public void fetchValuesOfHashMap()
	{
		Collection <Integer> myValues = hMap.values();
		System.out.println("The Values are ....");
		for(Integer i:myValues)
		{
			System.out.println(i);
		}
	}
	public void fetchEntriesOfHashMap()
	{
		Set <Entry <String,Integer>> myEntrySet = hMap.entrySet();
		Iterator <Entry<String,Integer>> myEntryIter = myEntrySet.iterator();
		while(myEntryIter.hasNext())
		{
			Entry <String,Integer> myEntry = myEntryIter.next();
			System.out.println("The Value for the Key :"+myEntry.getKey()+" is "+myEntry.getValue());
			
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMapSample hms = new HashMapSample();
		hms.populateHashMap();
		hms.fetchHashMapObjectsThruKeySet();
		System.out.println("---------The Values are-----");
		hms.fetchValuesOfHashMap();
		System.out.println("--------Fetch HMap through EntrySEt--------");
		hms.fetchEntriesOfHashMap();

	}

}
