package com.krpura.anu;

import java.util.ArrayList;
import java.util.Iterator;

public class SampleAList {

	ArrayList myList = new ArrayList();
	public void populateArrayList()
	{
		Employee employee1 = new Employee("E001","Kiran Kumar","RTNagar","8939939939",10000);
		myList.add(employee1);
		myList.add(new Employee("E002","Kishan Kumar","Malleswaram","7648939939",12000));
		myList.add(new Employee("E003","Keerthana","Koramangala","7648936459",13000));
		myList.add(new Employee("E004","Mohan Kumar","Indiranagar","7646579939",14000));
		myList.add(new Employee("E005","Sreedhar","Koramangala","7631239939",16000));
		myList.add(new Employee("E006","Michael","Vijayanagar","7648939879",15000));
	}
	public void displayArrayListElements()
	{
		//Displaying Raw 
		System.out.println(myList);
		System.out.println("-------------------");
		//Displaying using For Each loop
		for(Object e1:myList)
		{
			System.out.println("The Element is "+e1);
		}
		System.out.println("-------------------");
		//Iterator
		Iterator listIter = myList.iterator();
		while(listIter.hasNext())
		{
			Object e =  listIter.next();
			System.out.println(e);
			//System.out.println(listIter.next());
			
		}
		//
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SampleAList salt = new SampleAList();
		salt.populateArrayList();
		salt.displayArrayListElements();

	}

}
