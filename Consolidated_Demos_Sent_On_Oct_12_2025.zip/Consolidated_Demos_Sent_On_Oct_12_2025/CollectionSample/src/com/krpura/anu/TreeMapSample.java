package com.krpura.anu;

import java.util.Iterator;
import java.util.Map.Entry;
import java.util.NavigableSet; // Set which supports navigation in a direction
import java.util.Set;
import java.util.TreeMap;

public class TreeMapSample {

	TreeMap <String,Employee> tMap = new TreeMap<String,Employee>();
	public void populateTreeMap()
	{
		
		tMap.put("E006",new Employee("E006","Harsha","RTNagar","983939393",10000));
		tMap.put("E001",new Employee("E001","Kishan Kumar","Malleswaram","7648939939",12000));
		tMap.put("E005",new Employee("E005","Mohan Kumar","Indiranagar","7646579939",14000));
		tMap.put("E004",new Employee("E004","Kiran Kumar","RTNagar","983939393",10000));
		tMap.put("E003",new Employee("E003","Sreedhar","Koramangala","7631239939",16000));
		tMap.put("E002",new Employee("E002","Michael","Vijayanagar","7648939879",15000));
		tMap.put("E007",new Employee("E007","Mohan Kumar","Indiranagar","7646579939",14000));

	} //htable(keys/entryset/values)/hmap(keyset/values/entryset)/tmap(values/keyset/entryset)
	public void fetchTreeMapThruEntrySet()
	{
			// Set <String> myKeys = tMap.keySet(); values
		Set <Entry <String,Employee>> myEntrySet =  tMap.entrySet();
		Iterator <Entry <String,Employee>> myEntryIter = myEntrySet.iterator();
		while(myEntryIter.hasNext())
		{
			Entry <String,Employee> myEntry = myEntryIter.next();
			System.out.println("The Key is "+myEntry.getKey()+" And Corresponding Value is "+myEntry.getValue());
		}
	}
	public void fetchDescendingKeys()
	{
		NavigableSet <String> myNavigableKeySet =	tMap.descendingKeySet();
		Iterator <String> myNavigableIter = myNavigableKeySet.iterator();
		while(myNavigableIter.hasNext())
		{
		 String myKey = myNavigableIter.next();
		 System.out.println("The Key is "+myKey+" And corresponding Value is "+tMap.get(myKey));
		}
		Entry <String,Employee> myFirstEntry = tMap.firstEntry();
		System.out.println("The First Entry is "+myFirstEntry);
		Entry <String,Employee> myLastEntry = tMap.lastEntry();
		System.out.println("The Last Entry is "+myLastEntry);
		String  myFirstKey = tMap.firstKey();
		System.out.println("The First Key is "+myFirstKey);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMapSample tms = new TreeMapSample();
		tms.populateTreeMap();
		tms.fetchTreeMapThruEntrySet();
		
		tms.fetchDescendingKeys();

	}

}
