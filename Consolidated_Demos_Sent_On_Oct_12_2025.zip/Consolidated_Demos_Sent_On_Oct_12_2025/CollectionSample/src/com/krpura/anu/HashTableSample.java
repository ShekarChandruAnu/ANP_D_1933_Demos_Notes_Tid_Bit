package com.krpura.anu;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

public class HashTableSample {

	// Hashtable <String,Employee> hTable = new Hashtable<String,Employee>()
	//ArrayList <Employee> myEmployees = new ArrayList<>();
	// Hashtable <Key,Value> hTable = new Hashtable<>();
	Hashtable <String,Employee> hTable = new Hashtable<>();
	
	
	public void populateHashTable()
	{
		Employee e1 = new Employee("E001","Mallesh Kumar","Jayanagar","9393993939",12000);
		hTable.put("E001", e1);
		hTable.put("E002",new Employee("E002","Kishan Kumar","Malleswaram","7648939939",12000));
		hTable.put("E003",new Employee("E003","Keerthana","Koramangala","7648936459",13000));
		hTable.put("E004",new Employee("E004","Mohan Kumar","Indiranagar","7646579939",14000));
		hTable.put("E005",new Employee("E005","Sreedhar","Koramangala","7631239939",16000));
		hTable.put("E006",new Employee("E006","Michael","Vijayanagar","7648939879",15000));
		
		
	}
	public void fetchHashTableContent()
	{
		Enumeration <String> myKeys = hTable.keys();
		
		while(myKeys.hasMoreElements())
		{
			String myKey=myKeys.nextElement();
			Employee employee = hTable.get(myKey); 
			System.out.println("The Value for the Key "+myKey+" is "+employee);
		}
	}
	//ArrayList <String> myList = new ArrayList<String>()
	//ArrayList <Customer> myCustomers = new ArrayList<Customer>()
	//ArrayList <Product> products = new ArrayList<Product>()
	//Hashtable <String,Employee> ht = new Hashtable()
	//Set <Employee> empSet = new HashSet(); 
	
	public void fetchHashTableThruKeySet()
	{
		Set <String> myKeys = hTable.keySet();
			Iterator <String> keyIter = myKeys.iterator();
			while(keyIter.hasNext())
			{
				String myKey = keyIter.next();
				Employee emp = hTable.get(myKey);
				System.out.println("The Value for the Key "+myKey+" is "+emp);
			}
			
	}
	
	//Order insertion Sorted Order
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashTableSample hts = new HashTableSample();
		hts.populateHashTable();
		hts.fetchHashTableContent();
		System.out.println("-------");
		hts.fetchHashTableThruKeySet();
		
	}

}
