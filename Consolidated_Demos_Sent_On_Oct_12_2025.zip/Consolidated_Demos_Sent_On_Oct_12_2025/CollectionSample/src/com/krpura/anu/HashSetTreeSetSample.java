package com.krpura.anu;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class HashSetTreeSetSample {

	/*
	 * employees.add(new Employee("E001","Mallesh Kumar","Jayanagar","9393993939",12000));
		employees.add(new Employee("E002","Kishan Kumar","Malleswaram","7648939939",12000));
		employees.add(new Employee("E003","Keerthana","Koramangala","7648936459",13000));
		employees.add(new Employee("E004","Mohan Kumar","Indiranagar","7646579939",14000));
		employees.add(new Employee("E005","Sreedhar","Koramangala","7631239939",16000));
		employees.add(new Employee("E006","Michael","Vijayanagar","7648939879",15000));
		
	 */
	
	HashSet <String> hSet = new HashSet<String>();
	TreeSet <String> tSet = new TreeSet<String>();
	TreeSet <Employee> empTreeSet = new TreeSet<Employee>();
	
	
	//POPULATING THE HASHSET
	public void populateHashSet()
	{
		hSet.add("Ernakulam");
		hSet.add("Bangalore");
		hSet.add("Ahmedabad");
		hSet.add("Faridabad");
		hSet.add("Gandhinagar");
		hSet.add("Delhi");
		hSet.add("Chennai");
	}
	//FETCHING THE ELEMENTS OF HASHSET
	public void fetchHashSet()
	{
		Iterator <String> hSetIter = hSet.iterator();
		while(hSetIter.hasNext())
		{
			String city= hSetIter.next();
			System.out.println("The City is "+city);
		}
	}

	//POPULATING THE TREESET
	public void populateTreeSet()
	{
		tSet.add("Ernakulam");
		tSet.add("Bangalore");
		tSet.add("Ahmedabad");
		tSet.add("Faridabad");
		tSet.add("Gandhinagar");
		tSet.add("Delhi");
		tSet.add("Chennai");
	}
	//FETCHING THE TREESET ELEMENTS
	public void fetchTreeSet()
	{
		Iterator <String> tSetIter = tSet.iterator();
		while(tSetIter.hasNext())
		{
			String treeSetCity = tSetIter.next();
			System.out.println("The City is "+treeSetCity);
		}
	}
	public void populateEmployeeTreeSet()
	{
		//COMPARABLE INTERFACES WILL HELP US IN SORTING THE OBJECTS BASED ON A PARTICULAR FIELD
		
		empTreeSet.add(new Employee("E006","Michael","Vijayanagar","7648939879",15000));
		empTreeSet.add(new Employee("E001","Mallesh Kumar","Jayanagar","9393993939",12000));
		empTreeSet.add(new Employee("E004","Mohan Kumar","Indiranagar","7646579939",14000));
		empTreeSet.add(new Employee("E002","Kishan Kumar","Malleswaram","7648939939",12000));
		empTreeSet.add(new Employee("E003","Keerthana","Koramangala","7648936459",13000));
		empTreeSet.add(new Employee("E005","Sreedhar","Koramangala","7631239939",16000));
	}
	public void fetchEmployeeTreeSet()
	{
		Iterator <Employee> emptSetIter = empTreeSet.iterator();
		while(emptSetIter.hasNext())
		{
			Employee treeSetEmployee = emptSetIter.next();
			System.out.println("The Employee is "+treeSetEmployee);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSetTreeSetSample hsts = new HashSetTreeSetSample();
		System.out.println("----------HASHSET VALUES DISPLAYED--------");
		hsts.populateHashSet();
		hsts.fetchHashSet();
		System.out.println("----------TREESET VALUES DISPLAYED--------");
		hsts.populateTreeSet();
		hsts.fetchTreeSet();
		System.out.println("----------EmployeeTreeSet Displayed---------------");
		hsts.populateEmployeeTreeSet();
		hsts.fetchEmployeeTreeSet();
	}

}
