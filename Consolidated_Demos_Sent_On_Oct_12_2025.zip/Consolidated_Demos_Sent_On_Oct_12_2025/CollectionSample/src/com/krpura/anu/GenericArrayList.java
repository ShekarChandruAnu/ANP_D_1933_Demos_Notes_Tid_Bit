package com.krpura.anu;

import java.util.ArrayList;
import java.util.Iterator;

public class GenericArrayList {

	ArrayList <String> empNames = new ArrayList<String>();
	ArrayList <Employee> employees = new ArrayList<Employee>();
	ArrayList <Integer> empNumbers = new ArrayList<Integer>();
//	ArrayList <Employee> employees = new ArrayList<>();
	public void populateStringArrayList()
	{
		empNames.add("Kiran Kumar");
		empNames.add("Keerthana");
		empNames.add("Murali Mohan");
		empNames.add("Mohan Kumar");
		empNames.add("Rakesh Kumar");
		empNames.add("Rajesh ");
	}
	
	public void populateEmployeeArrayList()
	{
		employees.add(new Employee("E001","Mallesh Kumar","Jayanagar","9393993939",12000));
		employees.add(new Employee("E002","Kishan Kumar","Malleswaram","7648939939",12000));
		employees.add(new Employee("E003","Keerthana","Koramangala","7648936459",13000));
		employees.add(new Employee("E004","Mohan Kumar","Indiranagar","7646579939",14000));
		employees.add(new Employee("E005","Sreedhar","Koramangala","7631239939",16000));
		employees.add(new Employee("E006","Michael","Vijayanagar","7648939879",15000));
		employees.add(2, new Employee("E002a","SreeKumar","Koramangala","7648939939",12500));
		employees.remove(3);
	
	
	}
	public void populateIntegerArrayList()
	{
		empNumbers.add(1000);
		empNumbers.add(2000);
		empNumbers.add(3000);
		empNumbers.add(4000);
		empNumbers.add(5000);
		empNumbers.add(6000);
		
	}
	public void fetchStringArrayList()
	{
		System.out.println(empNames);
	}
	public void fetchEmployeeArrayList() {
		for(Employee emp : employees)
		{
			System.out.println("Employee : "+emp);
		}
	}
	public void fetchEmpNumbersThruIterator()
	{
		Iterator numIter = empNumbers.iterator();
		while(numIter.hasNext())
		{
			System.out.println("The Number is "+numIter.next());
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GenericArrayList gail = new GenericArrayList();
	//	gail.populateStringArrayList();
	//	gail.fetchStringArrayList();
		System.out.println("------");
		gail.populateEmployeeArrayList();
		gail.fetchEmployeeArrayList();
		System.out.println("------");
	//	gail.populateIntegerArrayList();
	//	gail.fetchEmpNumbersThruIterator();

	}

}
