package com.krpura.anu;

import java.util.Iterator;
import java.util.Stack;

public class StackSample {
	
	Stack <String> myStack = new Stack<>();
	
	public void populateStackThruAdd()
	{
		System.out.println("The Size of the Stack "+myStack.size());
		myStack.add("Amarendra");
		myStack.add("Brajesh");
		myStack.add("Chandan");
		System.out.println("The Size of the Stack "+myStack.size());
	}
	public void fetchFromStackThruIterator()
	{
		System.out.println("Size of the Stack before iterating "+myStack.size());
		Iterator <String> myStackIter = myStack.iterator();
		while(myStackIter.hasNext())
		{
			String myStackItem = myStackIter.next();
			System.out.println("The Stack Item is "+myStackItem);
		}
		System.out.println("Size of the Stack after iterating "+myStack.size());
		String peekedElement = myStack.peek();
		System.out.println("The PEEKED element from the Stack is "+peekedElement);
	}
	
	public void populateStackThruPush()
	{
		System.out.println("The Size of the Stack "+myStack.size());
		myStack.push("Hyderabad");
		myStack.push("Mumbai");
		myStack.push("Faridabad");
		myStack.push("Nagpur");
		myStack.push("Coimbatore");
		myStack.push("Ernakulam ");
		myStack.push("Chennai");
		myStack.push("Cochin");
		System.out.println("The Size of the Stack "+myStack.size());
		
	}
	public void fetchStackElementsThruPop()
	{
		System.out.println("The size of the Stack before popping out"+myStack.size());
		while(myStack.isEmpty() ==  false)
		{
			String stackElement = myStack.pop();
			System.out.println(" The Element Popped out was "+stackElement);
		}
		System.out.println("The size of the Stack after popping out"+myStack.size());
	}
	
	public static void main(String[] args)
	{
		StackSample stackSample = new StackSample();
		System.out.println("-----------Stack Elements through usual add/iterator--------");
		stackSample.populateStackThruAdd();
		stackSample.fetchFromStackThruIterator();
		System.out.println("----------Stack Elements through push n pop---------");
		stackSample.populateStackThruPush();
		stackSample.fetchStackElementsThruPop();
	}

}
