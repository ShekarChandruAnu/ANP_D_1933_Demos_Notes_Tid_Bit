package com.krpura.anu;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListSample {

	ArrayList myList = new ArrayList();
	
	ArrayList <Integer> myList1 = new ArrayList<>();
	public void manipulateArrayList()
	{
		myList.add("Suman");
		myList.add(203030.45);
		myList.add(true);
		myList.add(2000000);	/**/
		
	/*	myList.add("Suman");
		myList.add("Kiran");
		myList.add("Naresh");
		myList.add("Mahesh");
		myList.add("Sumanth");
		myList.add("Kareem");/**/
		
		/*myList.add(20000); //BOXING int to obj
		myList.add(30000);
		myList.add(40000);
		myList.add(50000);
		myList.add(60000);
		myList.add(70000);*/
		//GENERICS
	}
	public void fetchArrayListData()
	{
		//Method 1 FOR EACH
		for(Object obj:myList)
		{
			System.out.println("The Element is "+obj);
		}
		System.out.println("---------");
		Iterator myIter = myList.iterator();
		while(myIter.hasNext())
		{
			Object obj  =myIter.next();
			System.out.println("The Element is "+obj);
		}
	}
	//typeOf(obj)
	public void boxingUnBoxing()
	{
		int num1 = 1000;
		System.out.println("The value in numerical variable "+num1);
		Object obj = num1;// BOXING ; value type to reference type
		System.out.println("The Numerical in Object "+obj);
		int num2 = (int)obj; // UNBOXING reference type to value type - EXPLICIT 
		System.out.println("The ref type converted to value type "+num2);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayListSample als = new ArrayListSample();
	//	als.boxingUnBoxing();
		als.manipulateArrayList();
		als.fetchArrayListData();

	}

}
