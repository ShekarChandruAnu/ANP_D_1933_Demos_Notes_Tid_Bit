package com.krpura.anu;

public class Student implements Comparable <Student>{

	String studId;
	String studName;
	String studCity;
	int score;
	
	public Student() {
		super();
	}

	public Student(String studId, String studName, String studCity, int score) {
		super();
		this.studId = studId;
		this.studName = studName;
		this.studCity = studCity;
		this.score = score;
	}

	public String getStudId() {
		return studId;
	}

	public void setStudId(String studId) {
		this.studId = studId;
	}

	public String getStudName() {
		return studName;
	}

	public void setStudName(String studName) {
		this.studName = studName;
	}

	public String getStudCity() {
		return studCity;
	}

	public void setStudCity(String studCity) {
		this.studCity = studCity;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	@Override
	public String toString() {
		return "Student [studId=" + studId + ", studName=" + studName + ", studCity=" + studCity + ", score=" + score
				+ "]";
	}
// COMPARING STUDENT ID
/*	@Override
	public int compareTo(Student student) {
		// TODO Auto-generated method stub
		if(this.getStudId().compareTo(student.getStudId()) > 0)
		{
			return 1;
		}
		else if(this.getStudId().compareTo(student.getStudId()) < 0)
		{
			return -1;
		}
		else			// Hello    Hello     0   true      //Hello     Jello   -1 false //Jello    Hello 
		{
			return 0;
		}
	}*/
	// S003.compareTo("S002");  // 72     65    positive       65    72   negative
	//>0 <0 0
	// COMPARING STUDENT NAME
/*	@Override
	public int compareTo(Student student) {
		// TODO Auto-generated method stub
		if( this.getStudName().compareTo(student.getStudName()) > 0)
		{
			return 1;
		}
		else if(this.getStudName().compareTo(student.getStudName()) < 0)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	} */

	// Sort based on Student Score
	@Override
	public int compareTo(Student student) {
		// TODO Auto-generated method stub
	/*	
		if( new Integer(this.getScore()).compareTo(new Integer(student.getScore())) > 0 )
		{
			
		}
		
		Integer x = new Integer(this.getScore());
		Integer y = new Integer(student.getScore());
		if (x.compareTo(y) > 0)
		{
			
		}*/
		
		
		if(this.getScore() > student.getScore())
		{
			return -1;
		}
		else if(this.getScore() < student.getScore())
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	
	
	
}   
