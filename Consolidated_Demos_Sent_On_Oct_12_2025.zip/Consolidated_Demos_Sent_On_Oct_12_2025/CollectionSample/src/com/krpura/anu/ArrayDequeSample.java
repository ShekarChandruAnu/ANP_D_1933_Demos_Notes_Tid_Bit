package com.krpura.anu;

import java.util.ArrayDeque;
import java.util.Deque;

public class ArrayDequeSample {

	Deque <String> myDeque = new ArrayDeque <>();
	public void populateDeque()
	{
		myDeque.add("Ahmedabad");
		myDeque.add("Bangalore");
		myDeque.add("Faridabad");
		myDeque.add("Chennai");
		myDeque.add("Dhanbad");
		myDeque.add("Ernakulam");
		myDeque.addFirst("Agra");
		myDeque.addLast("Fatehpur");
	//FIFO
	}
	public void fetchDequeElements()
	{
		while(myDeque.isEmpty() == false)
		{
			String city = myDeque.remove();
			System.out.println("The City Removed from the Deque is "+city);
		}
		
	
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayDequeSample ads = new ArrayDequeSample();
		ads.populateDeque();
		ads.fetchDequeElements();

	}

}
