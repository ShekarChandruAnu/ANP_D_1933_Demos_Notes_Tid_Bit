package com.krpura.anu;

public class FurnitureShop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BookShelf shelf1 = new BookShelf();
		shelf1.acceptBookShelfDetails();
		shelf1.displayBookShelfDetails();
	
		shelf1.acceptFurnitureDetails();
		shelf1.displayFurnitureDetails();
		

	}

}
