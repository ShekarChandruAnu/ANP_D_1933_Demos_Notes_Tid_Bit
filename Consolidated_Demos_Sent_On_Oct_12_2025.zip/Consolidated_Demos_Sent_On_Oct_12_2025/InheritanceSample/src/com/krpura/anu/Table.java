package com.krpura.anu;

public class Table extends Furniture{
	
	int noOfLegs;

}
