package com.krpura.anu;

import java.util.Scanner;

public class Furniture {
	// Default private public protected
	//Ctrl+Shift+O (not zero it is O for Othello) 
	//Data members made protected can be accessible only by derived classes
	protected int length,width,height;
	//Scanner class is used to accept the data from the user through keyboard
	protected Scanner scan1 = new Scanner(System.in);

	//Default constructor
	public Furniture() {
		super();
	}

	//Overloaded Constructor
	public Furniture(int length, int width, int height) {
		super();
		this.length = length;
		this.width = width;
		this.height = height;
	}
	
	public void acceptFurnitureDetails()
	{
		System.out.println("Enter the furniture details ");
		System.out.println("Enter the Height of the Furniture ");
		height = scan1.nextInt();
		System.out.println("Enter the Length of the Furniture ");
		length = scan1.nextInt();
		System.out.println("Enter the Width of the Furniture");
		width = scan1.nextInt();
	}
	
	public void displayFurnitureDetails()
	{
		System.out.println("The Furniture Details are...");
		System.out.println("The Length is "+length);
		System.out.println("The Width is "+width);
		System.out.println("The Height is "+height);
	}
	
	
	

}
