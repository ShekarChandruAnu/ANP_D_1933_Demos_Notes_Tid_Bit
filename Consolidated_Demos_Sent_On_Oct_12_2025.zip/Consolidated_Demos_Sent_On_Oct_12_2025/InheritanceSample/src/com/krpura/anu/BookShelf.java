package com.krpura.anu;

//extends is the keyword to derive a class from a Parent class
//Super Class:Furniture
//Sub Class :BookShelf
public class BookShelf extends Furniture{
	
	int noOfShelves; // length height width

	public BookShelf() {
		super();
	}

	public BookShelf(int noOfShelves) {
		super();
		this.noOfShelves = noOfShelves;
	}
	
	public void acceptBookShelfDetails()
	{
		/*System.out.println("Enter the Length of the BookShelf");
		length = scan1.nextInt();
		System.out.println("Enter the Width of the BookSHelf ");
		width = scan1.nextInt();
		System.out.println("Enter the Height of the BookSHelf");
		height = scan1.nextInt();*/
		super.acceptFurnitureDetails();
		// super represents the instance of the parent class
		System.out.println("Enter the no  Of Shelves");
		noOfShelves = scan1.nextInt();
	
	}
	public void displayBookShelfDetails()
	{
		System.out.println("The Book SHelf Details are");
		/*System.out.println("The Length is "+length);
		System.out.println("The Width is "+width);
		System.out.println("The Height is "+height);*/
		super.displayFurnitureDetails();
		System.out.println("The No of SHelves in the Book Shelf is "+noOfShelves);
	}
	
	

}
