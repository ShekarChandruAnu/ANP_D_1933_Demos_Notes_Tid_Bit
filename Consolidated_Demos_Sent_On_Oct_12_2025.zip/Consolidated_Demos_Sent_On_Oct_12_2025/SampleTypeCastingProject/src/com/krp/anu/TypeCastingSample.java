package com.krp.anu;

public class TypeCastingSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int vari = 100;
		System.out.println("int value in its original "+vari);
		float varf ;
		varf = vari;
		// WIDE CAST - IMPLICIT CAST
		System.out.println(" int value converted to  float "+varf);
		
		//NARROW CAST - EXPLICIT
		float fVar = 234.56f;
		System.out.println("Float original value "+fVar);
		int iVar;
		iVar = (int) fVar;
		System.out.println("Float cast to int "+iVar);
		
		System.out.println("=======char int int= =====");
		char varC = 'A';
		int varI = varC; //IMPLICIT - WIDE
		System.out.println("Character in integer char to int variable "+varI);
		//byte -128 to 127
		
		int varX = 100;
		byte varb = (byte)varX; // NARROW
		System.out.println("Int to byte "+varb);
		
		int varX1 = 127;
		byte varb1 = (byte)varX1; // NARROW
		System.out.println("Int to byte "+varb1);
		//long to int narrow cast
		int varX2 = 129;
		byte varb2 = (byte)varX2; // NARROW
		System.out.println("Int to byte "+varb2);
		//128-256= -128

	}

}
