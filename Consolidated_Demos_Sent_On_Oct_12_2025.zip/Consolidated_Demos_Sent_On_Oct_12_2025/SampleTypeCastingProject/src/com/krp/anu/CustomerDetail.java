package com.krp.anu;

public class CustomerDetail {
	
	String customerId;
	String customerName;
	String customerPhone;
	String customerAddress;
	int purchaseValue;
	float salesTax;

	//Default Constructor or Parameterless
	//Constructor of the Class CustomerDetail to initialize the Data Members
	 public CustomerDetail()
	{
		customerId = "C001";
		customerName = "Rajendra";
		customerPhone = "9829292922";
		customerAddress = "Malleswaram";
		purchaseValue = 10000;
		salesTax = 12.34f;
	}/**/
	public void initializeData()
	{
		customerId = "C002";  
		customerName = "Nagendra"; 
		customerPhone = "9746292922";
		customerAddress = "Koramangala";
		purchaseValue = 15000;
		salesTax = 15.34f;
	}/**/
	// Hello + world   = Helloworld
	public void displayCustomerDetails()
	{
		System.out.println("The Customer Details are ");
		System.out.println("Customer ID :"+customerId); // CustomerId : C002
		System.out.println("customerName "+customerName);
		System.out.println("customerPhone "+customerPhone);
		System.out.println("customerAddress "+customerAddress);
		System.out.println("purchaseValue "+purchaseValue);
		System.out.println("salesTax "+salesTax);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CustomerDetail customer1 = new CustomerDetail();
		customer1.displayCustomerDetails();
		
		CustomerDetail customer2 = new CustomerDetail();
		customer2.initializeData();
		customer2.displayCustomerDetails();
		
		//DEFAULT CONSTRUCTOR- PARAMETERLESS CONSTRUCTOR

	}

}
