package com.krpura.anud;
class MyThread1 extends Thread
{
	public MyThread1()
	{
		start();
	}
	public void run()
	{
		System.out.println("Child thread created");
	}
}
public class ThreadClassSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("In Main Thread");
		System.out.println("The CHild Thread getting Invoked...");
		
		MyThread1 mt1 = new MyThread1();
		
		System.out.println("Back in the Main ThreAd....");
		
	}

}
