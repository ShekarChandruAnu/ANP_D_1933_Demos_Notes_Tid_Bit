package com.krpura.anud;
class MyThread implements Runnable
{
	//MyThread m1 = new MyThread();
	Thread t1;
	public MyThread()
	{
		t1 = new Thread(this, "Child Thread...."); // UNSTARTED STATE of the Thread
		t1.start(); // RUNNABLE STATE
		
		System.out.println("In the Constructor of the Child Thread....");
		
	}
	
	@Override
	public void run() { // main thread & child thread in race to execute
		// TODO Auto-generated method stub
		System.out.println("In the Child Thread");//3 //5
		System.out.println("Child Thread "+t1);//4 //6
		System.out.println("Exiting Child Thread....");//5  //7
	}
	
}
public class RunnableSampleThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Entering the Main Thread...");//1 correct
		System.out.println("About to Invoke Child Thread....");//2 correct
		
		MyThread mt1 = new MyThread();
		
		System.out.println("We finished Invoking child thread and Back in the Main Thread,,,...");//3 //6
		System.out.println("We are exiting Main Thread,,,,.....");//4 //7
		
	}

}
