package com.krpura.anud;
class MyThread2 implements Runnable
{
	Thread t1;
	
	public MyThread2()
	{
		t1 = new Thread(this,"Child Thread");
		t1.start();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Child Thread "+t1); // childthread,5,main
		for(int i=0;i<5;i++)
		{
			System.out.println("       Child Thread Loop "+(i+1));
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}/**/
		
		System.out.println("Exiting Child Thread...");
		
	}
	
}
public class RunnableSample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("In the Main Thread...");
		MyThread2 mt1 = new MyThread2();
		System.out.println("is The Child Thread alive "+mt1.t1.isAlive());
		
		try {
			mt1.t1.join();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		for(int i=0;i<5;i++)
		{
			System.out.println("Main Thread Loop "+(i+1));
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("is The Child Thread Still alive "+mt1.t1.isAlive());
		System.out.println("Back In the Main Thread....");
		System.out.println("Exiting Main Thread");

	}

}
