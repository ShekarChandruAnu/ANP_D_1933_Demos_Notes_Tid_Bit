package com.krpura.anud;

public class MainThreadSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Thread t1 =	Thread.currentThread();
			System.out.println("Current Thread "+t1);
			t1.setName("NewChild Thread");
			System.out.println("Current Thread after Name change "+t1);
	}

} // NORM_PRIORITY HIGHEST PRIORITY
// 1- 10
//t1 10
//t2   5
