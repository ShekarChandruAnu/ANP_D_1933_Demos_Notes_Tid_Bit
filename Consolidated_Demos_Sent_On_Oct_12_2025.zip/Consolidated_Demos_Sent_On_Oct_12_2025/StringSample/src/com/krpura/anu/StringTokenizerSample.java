package com.krpura.anu;

import java.util.StringTokenizer;

public class StringTokenizerSample {

	public void manipulateStringTokenizer()
	{
		StringTokenizer strTokens = new StringTokenizer("This is a sample"," ");
		while(strTokens.hasMoreElements())
		{
			System.out.println(strTokens.nextElement());
		}
		
		StringTokenizer strTokens1 = new StringTokenizer("World:is:challenging:place",":");
		while(strTokens1.hasMoreTokens())
		{
			System.out.println(strTokens1.nextToken());
		}
		
		StringTokenizer strTokens2 = new StringTokenizer("world,is,a,beautiful,place",",");
		while(strTokens2.hasMoreTokens())
		{
			System.out.println(strTokens2.nextToken());
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringTokenizerSample sts = new StringTokenizerSample();
		sts.manipulateStringTokenizer();

	}

}
