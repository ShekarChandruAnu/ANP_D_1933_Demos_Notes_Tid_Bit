package com.krpura.anu;

public class StringBuilderBufferSample {

	public void manipulateStringBuffernBuilder()
	{
		StringBuffer sbr = new StringBuffer("world is  beautiful place");
		System.out.println("Before insertion "+sbr);
		sbr.insert(9, 'A');
		System.out.println("After insertion "+sbr);
		
		sbr.insert(9, "challenging");
		System.out.println("after inserting again :"+sbr);
		
		StringBuilder sbldr = new StringBuilder("world is  beautiful place");
		System.out.println("Before insertion "+sbldr);
		sbldr.insert(9, 'A');
		System.out.println("After insertion "+sbldr);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilderBufferSample sbfr = new StringBuilderBufferSample();
		sbfr.manipulateStringBuffernBuilder();

	}

}
