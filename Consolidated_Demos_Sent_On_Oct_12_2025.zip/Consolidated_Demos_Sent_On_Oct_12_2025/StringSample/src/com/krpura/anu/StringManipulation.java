package com.krpura.anu;

public class StringManipulation {

	public void manipulateString()
	{
		String str1 = "Hyderabad";
				System.out.println("The Original Value in Str1 "+str1);
		str1 = "Vishakapatnam";
				System.out.println("The Changed Value rather pointer pointed  by Str1 "+str1);
				System.out.println("------------------------");
				String stra = "Hyderabad";
				String strb = "Hyderabad";
				System.out.println("The equivalence of stra and strb using stra.equals(strb) "+stra.equals(strb));//true
				System.out.println("The equivalence of stra and strb using == method "+(stra == strb)); //true
				String strc = new String("Hyderabad");
				String strd = new String("Hyderabad");
				System.out.println("------------------------");
				System.out.println("The equivalence of strc and strd using strc == strd) "+(strc==strd));//false
				System.out.println("The equivalence of trc and strd using strc.equals(strd)) "+strc.equals(strd));//T or F
				
				String strW = "world is beautiful ";
				System.out.println("strW.charAt(6) "+strW.charAt(6));
				System.out.println("strW.indexOf('b') :"+strW.indexOf('b'));
				System.out.println("strW.codePointAt(6) :"+strW.codePointAt(6));
				
				System.out.println(" strW.length() "+strW.length());
				String strX = "also challenging";
				System.out.println(" strW.concat(strX) "+strW.concat(strX));
				
				String strA = "Hyderabada";
				String strB = "Hyderabadb";
				System.out.println("strB.compareTo(strA) :"+strB.compareTo(strA));
				System.out.println(" strB.codePointAt(9) :" + strB.codePointAt(9));
				System.out.println(" strA.codePointAt(9) :" + strA.codePointAt(9));
				System.out.println("strA.compareTo(strB) :"+strA.compareTo(strB));
				
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringManipulation strManop = new StringManipulation();
		strManop.manipulateString();

	}

}
