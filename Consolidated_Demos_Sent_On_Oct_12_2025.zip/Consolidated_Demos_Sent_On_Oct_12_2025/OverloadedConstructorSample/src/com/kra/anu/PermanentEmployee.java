package com.kra.anu;

public class PermanentEmployee {

	Employee e1 = new Employee();
	public void acceptData()
	{
		e1.employeeId = "e003";
	}
}
