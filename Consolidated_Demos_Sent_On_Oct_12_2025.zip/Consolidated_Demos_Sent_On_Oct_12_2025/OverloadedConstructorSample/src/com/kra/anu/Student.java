package com.kra.anu;

public class Student {

	String studentId;
	String studentName;
	int score;
	public Student()
	{
		studentId = "S001";
		studentName = "Kiran";
		score = 89;
	}/**/
	// FUNCTION SIGNATURE DEFINES 
	//NO OF PARAMS
	//TYPE OF PARAMS
	//SEQUENCE OF PARAMS
	// OVERLOADING 
	public Student(String studentId,String studentName,int score)
	{
		this.studentId = studentId;
		this.studentName = studentName;
		this.score = score;
	}
	public Student(String studentId,int score,String studentName)
	{
		this.studentId = studentId;
		this.studentName = studentName;
		this.score = score;
	}
	public Student(String studentId,String studentName)
	{
		this.studentId = studentId;
		this.studentName = studentName;
	
	}/**/
	public void displayStudent()
	{
		System.out.println("Student Id "+studentId);
		System.out.println("Student Name "+studentName);
		System.out.println("Student score "+score); //Student Score 87
	}
	@Override
	public String toString() // Belongs to Object
	{
		String str = "The Student "+studentName+" With an ID "+studentId+" Has Secured a Score of"+score;
		return str;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student1 = new Student();
		student1.displayStudent();
		System.out.println("----------");
		Student student2 = new Student("S002","Suman",90);
		student2.displayStudent();
		
		
		Student student3 = new Student("S003",90,"Harsha");
		student2.displayStudent();
		
		System.out.println("The Student Details "+student3); // String + Object
		System.out.println("The Student Details "+student2);
		//toString()
		
		

	}

}
