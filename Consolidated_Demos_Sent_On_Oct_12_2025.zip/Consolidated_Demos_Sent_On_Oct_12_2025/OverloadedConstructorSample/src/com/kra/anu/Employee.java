package com.kra.anu;

public class Employee {

	/* default accessed anywhere in the package
	String employeeId; 
	String employeeName;
	String employeeAddress;
	int employeeSalary;
	float incomeTax;*/
	
	/* private accessible only within that class */
	 String employeeId; 
	 String employeeName;
	String employeeAddress;
	 int employeeSalary;
	float incomeTax;
	
	//Default constructor - Parameterless Constructor
	public Employee()
	{
		employeeId = "E001";
		employeeName="Kiran Kumar";
		employeeAddress="RTNagar";
		employeeSalary=1000;
		incomeTax=12.34f;
	}
	//Parameterized Constructor also called Overloaded
	//CONSTRUCTOR WITH HIGHEST DEGREE
	public Employee(String employeeId,String employeeName,String employeeAddress,int employeeSalary,float incomeTax) 
	{
		//this represents an instance of the current class
		//MIRRORING
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
		this.employeeSalary = employeeSalary;
		this.incomeTax = incomeTax;
	}
	// constructor with 3 parameters
	public Employee(String employeeId,String employeeName,String employeeAddress) 
	{
		//this represents an instance of the current class
		//MIRRORING
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
		
	}
	// constructor with 2 parameters
	//CONSTRUCTOR WITH LOWEST DEGREE
	public Employee(String employeeId,String employeeName) 
	{
		//this represents an instance of the current class
		//MIRRORING
		this.employeeId = employeeId;
		this.employeeName = employeeName;
	}
	public void displayEmployeeDetails()
	{
		System.out.println("The Employee Details are.....");
		System.out.println("Employee Id "+employeeId);
		System.out.println("Employee Name "+employeeName);
		System.out.println("Employee Address "+employeeAddress);
		System.out.println("Employee Salary "+employeeSalary);
		System.out.println("Employee liable for a Tax of "+incomeTax);
	}

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee mohan = new Employee();
		mohan.displayEmployeeDetails();
		System.out.println("------");
		Employee suman = new Employee("E002","Shashi Kumar","Malleswaram",2000,13.45f);
		suman.displayEmployeeDetails();
		System.out.println("------");
		Employee harish = new Employee("E003","Harish Kumar","Koramangala");
		harish.displayEmployeeDetails();
		System.out.println("------");
		Employee mahesh = new Employee("E004","mahesh Kumar");
		mahesh.displayEmployeeDetails();
	}

}
