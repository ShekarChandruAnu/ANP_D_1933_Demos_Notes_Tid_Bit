package com.fra.anu;

import java.util.Scanner;

public class EmployeeData {
	
	// Variables Naming Conventions : Lower Camel Case
	String employeeName;
	String employeePhone;
	String employeeAddress;
	String employeeEmail;
	int employeeSalary ;  //float 7   double 15
	float incomeTax;
	Scanner scanner = new Scanner(System.in);
	
	// Method to Initialize the Data members
	public void getEmployeeData()
	{
		//VARIABLES INITIALIZED
		employeeName = "Harsha";
		employeePhone = "98393939399";
		employeeAddress = "RTNagar";
		employeeEmail = "harsh@gmail.com";
		employeeSalary = 1000;
		incomeTax = 12.34f;
	}
	public void acceptEmployeeData()
	{
		System.out.println("Enter the Employee Name ");
		employeeName  = scanner.next();
		
		System.out.println("Enter the Employee Phone");
		employeePhone = scanner.next();
		
		System.out.println("Enter the Employee Address");
		employeeAddress = scanner.next();
		
		System.out.println("Enter the Employee Salary ");
		employeeSalary = scanner.nextInt();
		
		System.out.println("Enter the Income Tax applicable for the employee");
		incomeTax = scanner.nextFloat();
		
	}
	//Method to display the Values of the Data Members
	public void displayEmployeeData()
	{
		System.out.println("----Employee Details are----");
		System.out.println("Employee Name is "+employeeName);
		System.out.println("Employee Phone is "+employeePhone);
		System.out.println("Employee EMail is "+employeeEmail);
		System.out.println("Employee Salary is "+employeeSalary);
		System.out.println("Employee Income Tax is "+incomeTax);
	}

	//ENTRY POINT FOR THE APPLICATION is the main  method
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeData ramesh = new EmployeeData();// creating an instance of the class EmployeeData
		//ramesh.getEmployeeData();
		ramesh.acceptEmployeeData(); // CALLING METHODS
		ramesh.displayEmployeeData();
		
		
	}

}
