package com.krpura.anu;

public class ArrayIndexExceptionSample {   

	int arr[] = new int[10];
	public void manipulateArray()
	{
		System.out.println("We entered Array Manipulation method");
		for(int i=0;i<=10;i++)
		{
			try
			{
			arr[i] = (i+1)*10;
			System.out.println("The Array Value is "+arr[i]);
			}
			catch(ArrayIndexOutOfBoundsException aie)
			{
				//aie.printStackTrace();
				System.out.println(aie.getMessage());
			}
		}
		System.out.println("We are exiting Array Manipulation method");
	}
	//main method to invoke all user defined methods
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("We are in Main Method");
		System.out.println("We are abt to invokde Array Method ");
		
		ArrayIndexExceptionSample aies = new ArrayIndexExceptionSample();
		aies.manipulateArray();
		
		System.out.println("We are back in the Main");
		System.out.println("Exiting Main");
	}

}
