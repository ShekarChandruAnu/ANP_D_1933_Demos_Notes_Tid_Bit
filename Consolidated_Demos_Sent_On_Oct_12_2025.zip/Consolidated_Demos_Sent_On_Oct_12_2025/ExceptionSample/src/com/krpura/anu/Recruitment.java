package com.krpura.anu;

public class Recruitment {

	public void callCheckAge(int age)
	{
		try {
			System.out.println("welcome"); // open a file
			checkAge(age);				// write afile throw
										// close  file
		} catch (InvalidAgeException e) {
			// TODO Auto-generated catch block
			//throw e;
			e.printStackTrace();
			System.out.println("----------------");
			System.out.println(e.message);
			System.out.println("----------------");
			//close  file
		}
		finally
		{
			System.out.println("Any ways we come here....Irrespective of Exception thrown or not");
		}
	}
	public void checkAge(int age) throws InvalidAgeException 
	{
		System.out.println("We are checking the age thru Recruitment Process ");
		System.out.println("The AGe of the Candidate is "+age);
		if(age < 20 || age > 30)
		{
			System.out.println("Sorry Invalid Age");
			 /*InvalidAgeException iae = new InvalidAgeException("Valid Age is in the Range 20-30");
			throw iae;*/
			throw new InvalidAgeException("Valid Age is in the Range 20-30");
		}
		System.out.println("We have finished Age scrutiny proceed with remaining Recruitment process");
		System.out.println("---------");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Recruitment rc = new Recruitment();
		/*try
		{*/
			rc.callCheckAge(23);
			rc.callCheckAge(21);
			rc.callCheckAge(33);
			rc.callCheckAge(25);
			rc.callCheckAge(26);
		/*}
		catch(InvalidAgeException iae)
		{
			System.out.println("Age Exception :"+iae.message);
		}*/
	}

}
