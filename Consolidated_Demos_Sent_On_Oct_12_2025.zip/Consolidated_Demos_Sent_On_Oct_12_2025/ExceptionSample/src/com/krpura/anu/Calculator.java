package com.krpura.anu;

public class Calculator {

	public void calculateDividend(int num1,int num2)
	{
		int result=0;
		System.out.println("We are in the Division Method");
		try
		{
			result = num1 / num2;
		}
		catch(ArithmeticException ae)
		{
			ae.printStackTrace();
		}
		System.out.println(" The Result after dividing num1 :"+num1+" by num2 :"+num2+" Is "+result);
		System.out.println("We finished Division Activity..");
		System.out.println("------------");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("We are in Main Method...");
		System.out.println("We Are about to invoke divide Method");
		Calculator calci = new Calculator();
	/*	try
		{*/
		calci.calculateDividend(100, 50);
		calci.calculateDividend(100, 25);
		calci.calculateDividend(100, 0);
		calci.calculateDividend(100, 20);
		calci.calculateDividend(100, 10);
	/*	}
		catch(ArithmeticException ae)
		{
		//	ae.printStackTrace();
			System.out.println(ae.getMessage());
		}*/
		System.out.println("We finished invoking divide Method");
		System.out.println("We are exiting Main Method...");

	}

}
