package com.krpura.anu;
class Shapes
{
	public void draw()
	{
		System.out.println("Drawing Random Shapes");
	}
	public final void paintShape()
	{
		System.out.println("Painting the Shape with Blue Color");
	}
}
class Rectangle extends Shapes
{
	@Override 
	public void draw()
	{
		System.out.println("Drawing Rectangles");
	}
	
	/*@Override FINAL METHOD CANNOT BE OVERRIDDEN
	public final void paintShape()
	{
		System.out.println("Painting the Shape with RED Color");
	}*/
}
final class GSTCalculator
{
	public void calculateGST()
	{
		
	}
}

// SOLID PRINCIPLES
// DESIGN PATTERNS
/*class TamilNaduTaxCalculator extends GSTCalculator //CANNOT INHERIT A FINAL CLASS
{
	
}*/
public class FinalSampleClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
