package com.krpura.anu;

public class StaticExample {
	
	int nonStaticVar;
	static int staticVar;
	final static int GRACEMARK=10;
	
	//static methods can access only static variables
	public static void staticMethod1()
	{
		staticVar++; // 1
		
		System.out.println("The Static Variable in Static Method 1  :"+staticVar);
	}
	//non static methods can access static & non static variables
	public void nonStaticMethod1()
	{
		//graceMark = 11;
		staticVar++;
		nonStaticVar++;
		System.out.println("The Static Variable in Non Static Method 1 :"+staticVar);
		System.out.println("The Non Static Variable in Non STatic Method 1 :"+nonStaticVar);
	}
	public static void staticMethod2()
	{
		staticVar++;
		System.out.println("The Static Variable in Static Method2  :"+staticVar);
	}
	public void nonStaticMethod2()
	{
		staticVar++;
		nonStaticVar++;
		System.out.println("The Static Variable in Non Static Method2 :"+staticVar);
		System.out.println("The Non Static Variable in Non Static Method2 :"+nonStaticVar);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StaticExample stat1 = new StaticExample();
		StaticExample.staticMethod1();		//sv : 1 // CORRECT
		stat1.nonStaticMethod1();	// sv: 2  nsv: 1
		stat1.nonStaticMethod2();   // sv: 3  nsv: 2  
		
		StaticExample stat2 = new StaticExample();
		StaticExample.staticMethod2(); // sv: amit 1 : sv: Navya 4
		stat2.nonStaticMethod1(); // sv:harish 5   nsv: (Teja)3   nsv:harish 1
		stat2.nonStaticMethod2(); // sv: harish 6     nsv:harish 2  Teja 4

	}

}
