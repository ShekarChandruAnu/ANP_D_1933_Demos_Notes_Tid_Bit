package com.krpura.anu;

public class MyStaticSample {

	int num1=10;
	static int num2 = 20;
	
	public void manipulateData()
	{
		num2 = 25;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
