package com.krpura.play;

public class PolySample {

//Just by changing the return type and keeping the function signature smae,
	//java does not consider it as  method overloading 
public void add(int a,int b,int c)
{

}
public void add(int a,int b,String c)
{

}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
