package com.krpura.anu;
class Thread1 
{
	public void processOrder()
	{
		System.out.println("Produced Order ...");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Consumed Order....");
		
	}
}
class MyThread extends Thread
{
	Thread1 th1;
	public MyThread(Thread1 th1)
	{
		this.th1 = th1;
	//	start();
	}
	public void run()
	{
		th1.processOrder();
		/*
		 * call x
		 * call y
		 */
	}
}
public class NonSynchronized {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread1 th1 = new Thread1();
		MyThread mth1 = new MyThread(th1);
		MyThread mth2 = new MyThread(th1);
		mth1.start();
		mth2.start();

	}

}
