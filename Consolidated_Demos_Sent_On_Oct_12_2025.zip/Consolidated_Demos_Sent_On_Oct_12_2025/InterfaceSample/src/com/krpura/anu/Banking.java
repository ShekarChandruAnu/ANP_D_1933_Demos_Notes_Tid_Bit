package com.krpura.anu;

public class Banking implements Account ,InsuranceAccount{

	@Override
	public void calculateOutstandingAmt() {
		// TODO Auto-generated method stub
		System.out.println("The Outstanding Amount Pending is XXXXXXX ");
		
	}

	@Override
	public void calculateRedemptionPoints() {
		// TODO Auto-generated method stub
		System.out.println("The Toal Redemption Points is YYYYY");
		
	}

	@Override
	public void withdrawAmount() {
		// TODO Auto-generated method stub
		System.out.println("The Amount is withdrawn Successfully.....");
		
	}

	@Override
	public void checkBalance() {
		// TODO Auto-generated method stub
		System.out.println("The Balance amount in your account is .......");
		
	}

	@Override
	public void depositAmount() {
		// TODO Auto-generated method stub
		System.out.println("The Amount is deposited successfully......");
		
	}

	@Override
	public void calculatePremium() {
		// TODO Auto-generated method stub
		System.out.println("The Premium Calculated for your Policy is .....");
		
	}

	@Override
	public void createPolicy() {
		// TODO Auto-generated method stub
		System.out.println("The Policy Is Created Successcfully.....");
		
	}

	@Override
	public void terminatePolicy() {
		// TODO Auto-generated method stub
		System.out.println("The Policy is Terminated successfully");
		
	}

	@Override
	public void createAccount() {
		// TODO Auto-generated method stub
		System.out.println("The Account is Created successfully");
	}

	@Override
	public void closeACcount() {
		// TODO Auto-generated method stub
		System.out.println(" The ACcount is Closed successfully,....");
		
	}

	@Override
	public void calculateInterest() {
		// TODO Auto-generated method stub
		System.out.println("The Interest Calculated is .....");
		
	}
	
	public static void main(String[] args)
	{
		Banking sbiAccount = new Banking();
		sbiAccount.createAccount();
		sbiAccount.calculateInterest();
		// DEBIT CARD RELATED ACTIVITIES
		sbiAccount.depositAmount();
		sbiAccount.withdrawAmount();
		sbiAccount.checkBalance();
		
		//CREDT CARD RELATED ACTIVITIES
		sbiAccount.calculateOutstandingAmt();
		sbiAccount.calculateRedemptionPoints();
		
		//INSURANCE RELATED
		sbiAccount.createPolicy();
		sbiAccount.calculatePremium();
		sbiAccount.terminatePolicy();
		
		sbiAccount.closeACcount();
	}

	
}
