package com.krpura.anu;

public interface DebitCardAccount {
	
	

		public void withdrawAmount();
		public void checkBalance();
		public void depositAmount();

}
