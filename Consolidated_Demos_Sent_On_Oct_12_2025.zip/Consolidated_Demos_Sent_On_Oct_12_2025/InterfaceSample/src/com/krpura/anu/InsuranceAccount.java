package com.krpura.anu;

public interface InsuranceAccount {
	
	public void calculatePremium();
	public void createPolicy();
	public void terminatePolicy();

}
