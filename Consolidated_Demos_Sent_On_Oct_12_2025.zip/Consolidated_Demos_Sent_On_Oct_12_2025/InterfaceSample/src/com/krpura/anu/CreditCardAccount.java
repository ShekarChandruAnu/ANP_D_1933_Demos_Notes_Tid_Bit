package com.krpura.anu;

public interface CreditCardAccount {
	public void calculateOutstandingAmt();
	public void calculateRedemptionPoints();

}
