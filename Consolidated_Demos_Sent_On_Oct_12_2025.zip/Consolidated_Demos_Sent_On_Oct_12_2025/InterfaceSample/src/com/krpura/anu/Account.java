package com.krpura.anu;

public interface Account extends CreditCardAccount,DebitCardAccount{

	public void createAccount();
	public void closeACcount();
	public void calculateInterest();
}
