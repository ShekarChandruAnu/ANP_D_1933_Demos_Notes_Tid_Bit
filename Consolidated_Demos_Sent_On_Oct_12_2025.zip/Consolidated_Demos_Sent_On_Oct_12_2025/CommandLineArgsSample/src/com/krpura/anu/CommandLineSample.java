package com.krpura.anu;

public class CommandLineSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("We are Utilizing the Command Line Args");
		//ARGS is an array - length of the array - elements are there in ARRAY
		// length is a property defined in Array class
		// length is available as a method too in STring class
		for(int i=0;i<args.length;i++)
		{
			System.out.println("The City is "+args[i]);
		}
			System.out.println("Enter your Name");
//com.krpura.anu.CommandLineSample
	}

}
